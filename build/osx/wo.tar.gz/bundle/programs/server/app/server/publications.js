(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/*collection publication*/                                             //
publish({                                                              // 2
    datasets: Datasets,                                                // 3
    apps: Apps,                                                        // 4
    groups: Groups,                                                    // 5
    userNames: Meteor.users                                            // 6
}, Meteor.publish, function (collection) {                             //
    return function () {                                               // 8
        var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
        var selector = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
                                                                       //
        //check(options, {                                             //
        //    fields: Match.Optional(Object),                          //
        //    skip: Match.Optional(Object),                            //
        //    sort: Match.Optional(Object),                            //
        //    limit: Match.Optional(Number)                            //
        //});                                                          //
        if (!selector) {                                               // 15
            selector = {};                                             // 16
        }                                                              //
                                                                       //
        if (!options) {                                                // 19
            options = {};                                              // 20
        }                                                              //
                                                                       //
        check(selector, Object);                                       // 23
                                                                       //
        switch (collection) {                                          // 25
            case Meteor.users:                                         // 26
                options.fields = { username: 1 };                      // 27
                break;                                                 // 28
                                                                       //
            case Datasets:                                             // 28
                var userId = this.userId;                              // 31
                extendOr(selector, viewsDocumentQuery(userId));        // 32
                options.fields = {                                     // 33
                    //'distribution.url': 0,                           //
                    'distribution.file': 0,                            // 35
                    'distribution.profile.username': 0,                // 36
                    'distribution.profile.pass': 0                     // 37
                };                                                     //
                break;                                                 // 39
                                                                       //
            case Apps:                                                 // 41
                userId = this.userId;                                  // 42
                extendOr(selector, viewsDocumentQuery(userId));        // 43
                break;                                                 // 44
        }                                                              // 44
                                                                       //
        return collection.find(selector, options);                     // 47
    };                                                                 //
});                                                                    //
                                                                       //
publish({ singleDataset: Datasets, singleApp: Apps, singleGroup: Groups }, Meteor.publish, function (collection) {
    return function (id) {                                             // 52
        var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
                                                                       //
        check(id, String);                                             // 53
                                                                       //
        var selector = { _id: id },                                    // 55
            userId = this.userId;                                      //
                                                                       //
        extendOr(selector, viewsDocumentQuery(userId));                // 58
        options.fields = {                                             // 59
            //'distribution.url': 0,                                   //
            'distribution.file': 0,                                    // 61
            'distribution.profile.username': 0,                        // 62
            'distribution.profile.pass': 0                             // 63
        };                                                             //
                                                                       //
        return collection.find(selector, options);                     // 66
    };                                                                 //
});                                                                    //
                                                                       //
Meteor.publish('comments', function (entryId) {                        // 70
    check(entryId, String);                                            // 71
    return Comments.find({ entryId: entryId });                        // 72
});                                                                    //
                                                                       //
Meteor.publish('notifications', function () {                          // 75
    return Notifications.find({ userId: this.userId, read: false });   // 76
});                                                                    //
                                                                       //
Meteor.publish('images', function () {                                 // 79
    return Images.find();                                              // 80
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
