(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/config.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 11/01/2016.                                      //
 */                                                                    //
                                                                       //
Meteor.startup(function () {                                           // 5
    var settings = Meteor.settings;                                    // 6
                                                                       //
    //create admin                                                     //
    if (!settings.admin) {                                             // 9
        settings.admin = { name: 'admin', username: 'admin', email: 'admin@webobservatory.org', password: 'admin' };
    }                                                                  //
                                                                       //
    if (!Accounts.findUserByUsername(settings.admin.username)) {       // 13
        var xgfdId = Accounts.createUser({                             // 14
            profile: {                                                 // 15
                name: settings.admin.name                              // 16
            },                                                         //
            username: settings.admin.username,                         // 18
            email: settings.admin.email,                               // 19
            password: settings.admin.password                          // 20
        });                                                            //
                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);             // 23
        Roles.addUserToRoles(xgfdId, ["admin"]);                       // 24
    }                                                                  //
                                                                       //
    // 1. Set up stmp                                                  //
    //   your_server would be something like 'smtp.gmail.com'          //
    //   and your_port would be a number like 25                       //
                                                                       //
    if (settings.smtp) {                                               // 31
        process.env.MAIL_URL = 'smtp://' +                             // 32
        //encodeURIComponent(your_username) + ':' +                    //
        //encodeURIComponent(your_password) + '@' +                    //
        encodeURIComponent(settings.smtp);                             // 35
    }                                                                  //
                                                                       //
    // Add Facebook configuration entry                                //
                                                                       //
    if (settings.facebook) {                                           // 40
        ServiceConfiguration.configurations.update({ "service": "facebook" }, {
            $set: {                                                    // 44
                "appId": settings.facebook.appId,                      // 45
                "secret": settings.facebook.secret                     // 46
            }                                                          //
        }, { upsert: true });                                          //
    }                                                                  //
                                                                       //
    // Add GitHub configuration entry                                  //
    if (settings.github) {                                             // 54
        ServiceConfiguration.configurations.update({ "service": "github" }, {
            $set: {                                                    // 58
                "clientId": settings.github.clientId,                  // 59
                "secret": settings.github.secret                       // 60
            }                                                          //
        }, { upsert: true });                                          //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=config.js.map
