(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/notifications.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 13/01/2016.                                      //
 */                                                                    //
                                                                       //
createNotification = function (initiatorId, entryId, entryName, userId, category, message) {
    var actions = arguments.length <= 6 || arguments[6] === undefined ? false : arguments[6];
                                                                       //
    check(initiatorId, String);                                        // 6
    check(entryId, String);                                            // 7
    check(entryName, String);                                          // 8
    check(userId, String);                                             // 9
    check(category, String);                                           // 10
    check(message, String);                                            // 11
    check(actions, Match.Any);                                         // 12
                                                                       //
    if (initiatorId !== userId) {                                      // 14
        Notifications.update({                                         // 15
            userId: userId,                                            // 16
            initiatorId: initiatorId,                                  // 17
            category: category,                                        // 18
            entryId: entryId,                                          // 19
            entryName: entryName,                                      // 20
            message: message,                                          // 21
            actions: actions,                                          // 22
            read: false                                                // 23
        }, {                                                           //
            $set: {                                                    // 25
                userId: userId,                                        // 26
                initiatorId: initiatorId,                              // 27
                category: category,                                    // 28
                entryId: entryId,                                      // 29
                entryName: entryName,                                  // 30
                message: message,                                      // 31
                actions: actions,                                      // 32
                read: false                                            // 33
            }                                                          //
        }, { upsert: true });                                          //
    }                                                                  //
};                                                                     //
                                                                       //
Meteor.methods({                                                       // 39
    createNotification: createNotification,                            // 40
    createRequestNotification: function (username, organisation, initiatorId, entry, category, note) {
        check(username, String);                                       // 42
        check(organisation, String);                                   // 43
        check(initiatorId, String);                                    // 44
        check(entry, Object);                                          // 45
        check(category, String);                                       // 46
                                                                       //
        var path = Router.routes[category + '.page'].path({ _id: entry._id });
                                                                       //
        var message = '<strong>' + username + '</strong>' + (organisation ? ' of ' + '<strong>' + organisation + '</strong>' : '') + ' requested access to ' + (category + ' <a class="blue-text" href="' + path + '">' + entry.name + '</a><br>') + (note ? '"' + note + '"' : ""),
            actions = ['Allow', 'Deny'];                               //
                                                                       //
        createNotification(initiatorId, entry._id, entry.name, entry.publisher, category, message, actions);
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=notifications.js.map
