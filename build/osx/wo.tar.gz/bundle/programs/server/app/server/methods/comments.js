(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/comments.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 13/01/2016.                                      //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 5
    commentInsert: function (commentAttributes, category) {            // 6
        check(this.userId, String);                                    // 7
        check(category, Mongo.Collection);                             // 8
        check(category.singularName, Match.OneOf('dataset', 'app'));   // 9
        check(commentAttributes, {                                     // 10
            entryId: String,                                           // 11
            body: String                                               // 12
        });                                                            //
                                                                       //
        entry = category.findOne(commentAttributes.entryId);           // 15
                                                                       //
        if (!entry) throw new Meteor.Error('invalid-comment', 'You must comment on ' + category);
                                                                       //
        comment = _.extend(commentAttributes, {                        // 20
            publisher: this.userId,                                    // 21
            category: category.singularName,                           // 22
            //author: user.username,                                   //
            submitted: new Date()                                      // 24
        });                                                            //
                                                                       //
        // update the post with the number of comments                 //
        category.update(comment.entryId, { $inc: { commentsCount: 1 } });
                                                                       //
        // create the comment, save the id                             //
        comment._id = Comments.insert(comment);                        // 31
                                                                       //
        // now create a notification, informing the user that there's been a comment
        createCommentNotification(comment, category);                  // 34
                                                                       //
        return comment._id;                                            // 36
    }                                                                  //
});                                                                    //
                                                                       //
function createCommentNotification(comment, category) {                // 40
    check(comment, Object);                                            // 41
    check(category, Mongo.Collection);                                 // 42
    check(category.singularName, Match.OneOf('dataset', 'app'));       // 43
                                                                       //
    var entryId = comment.entryId,                                     // 45
        entry = category.findOne(entryId),                             //
        initiatorId = comment.publisher;                               //
                                                                       //
    var path = Router.routes[category.singularName + '.page'].path({ _id: entryId });
    var message = '<a href="' + path + '"> <strong>' + Meteor.users.findOne(initiatorId).username + '</strong> commented on your post </a>';
                                                                       //
    if (initiatorId !== entry.publisher) {                             // 52
        createNotification(initiatorId, entryId, entry.name, entry.publisher, category.singularName, message);
    }                                                                  //
};                                                                     //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=comments.js.map
