(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/_utils.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 25/12/2015.                                      //
 */                                                                    //
                                                                       //
/*                                                                     //
 * For each @name:@collection pair in @sources, publish @collection under @name using @publisher
 * The callback of @publisher is constricted by @cbGen(@name, @collection)->function
 */                                                                    //
publish = function (sources, publisher, cbGen) {                       // 9
    for (var _name in babelHelpers.sanitizeForInObject(sources)) {     // 10
        if (sources.hasOwnProperty(_name)) {                           // 11
            publisher(_name, cbGen(sources[_name], _name));            // 12
        }                                                              //
    }                                                                  //
};                                                                     //
                                                                       //
JSONStream = Meteor.npmRequire('JSONStream');                          // 17
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=_utils.js.map
