(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var FileCollection = Package['vsivsi:file-collection'].FileCollection;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/vsivsi_orion-file-collection/index.js                                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
////////////////////////////////////////////////////////////////////////////////                     //
//  Copyright (C) 2015 by Vaughn Iverson                                                             //
//  orion-file-collection is free software released under the MIT/X11 license.                       //
//  See included LICENSE file for details.                                                           //
////////////////////////////////////////////////////////////////////////////////                     //
                                                                                                     //
var fc = new FileCollection("data", {                                                                // 7
   resumable: true,                                                                                  // 8
   resumableIndexName: 'resumableIndex',                                                             // 9
   http: [{                                                                                          // 10
      method: 'get',                                                                                 // 11
      path: '/id/:_id',                                                                              // 12
      lookup: function (params, query) {                                                             // 13
         return { _id: params._id };                                                                 // 13
      }                                                                                              //
   }]                                                                                                //
});                                                                                                  //
                                                                                                     //
if (Meteor.isServer) {                                                                               // 17
   // These need to be tightened down to enforce                                                     //
   fc.allow({                                                                                        // 19
      insert: function () {                                                                          // 20
         return true;                                                                                // 21
      },                                                                                             //
      remove: function () {                                                                          // 23
         return true;                                                                                // 24
      },                                                                                             //
      write: function () {                                                                           // 26
         return true;                                                                                // 27
      },                                                                                             //
      read: function () {                                                                            // 29
         return true;                                                                                // 30
      }                                                                                              //
   });                                                                                               //
}                                                                                                    //
                                                                                                     //
if (Meteor.isClient) {                                                                               // 35
                                                                                                     //
   // When a file is added                                                                           //
   fc.resumable.on('fileAdded', function (resFile) {                                                 // 38
      // Create a new file in the file collection to upload to                                       //
      fc.insert({                                                                                    // 40
         _id: resFile.uniqueIdentifier, // This is the ID resumable will use                         // 41
         filename: resFile.fileName,                                                                 // 42
         contentType: resFile.file.type                                                              // 43
      }, function (err, _id) {                                                                       //
         if (err) {                                                                                  // 46
            console.warn("File creation failed!", err);                                              // 47
            return;                                                                                  // 48
         }                                                                                           //
         // Once the file exists on the server, start uploading                                      //
         fc.resumable.upload();                                                                      // 51
      });                                                                                            //
   });                                                                                               //
                                                                                                     //
   // Update the upload progress session variable                                                    //
   fc.resumable.on('fileProgress', function (resFile) {                                              // 57
      resFile.file._orionCallbacks.progress(resFile.progress() * 100);                               // 58
      return;                                                                                        // 59
   });                                                                                               //
                                                                                                     //
   // Finish the upload progress in the session variable                                             //
   fc.resumable.on('fileSuccess', function (resFile) {                                               // 63
      var fileUrl = /* JJR Meteor.absoluteUrl()*/'/' + "gridfs/data/id/" + resFile.uniqueIdentifier;
      // console.log("Success!", resFile, fileUrl);                                                  //
      resFile.file._orionCallbacks.success(fileUrl, { gridFS_id: resFile.uniqueIdentifier });        // 66
      return;                                                                                        // 67
   });                                                                                               //
                                                                                                     //
   // More robust error handling needed!                                                             //
   fc.resumable.on('fileError', function (resFile, msg) {                                            // 71
      console.warn("Error uploading", resFile.uniqueIdentifier);                                     // 72
      resFile.file._orionCallbacks.failure(new Error(msg));                                          // 73
      return;                                                                                        // 74
   });                                                                                               //
                                                                                                     //
   orion.filesystem.providerUpload = function (options, success, failure, progress) {                // 77
      // Handle multiple files upload                                                                //
      for (var x = 0; x < options.fileList.length; x++) {                                            // 79
         var file = options.fileList[x];                                                             // 80
         // This lets the event handlers above invoke the correct callbacks                          //
         file._orionCallbacks = {                                                                    // 82
            success: success,                                                                        // 83
            failure: failure,                                                                        // 84
            progress: progress                                                                       // 85
         };                                                                                          //
                                                                                                     //
         fc.resumable.addFile(file);                                                                 // 88
      }                                                                                              //
   };                                                                                                //
                                                                                                     //
   orion.filesystem.providerRemove = function (fileObj, success, failure) {                          // 92
                                                                                                     //
      fc.remove({ _id: fileObj.meta.gridFS_id }, function (err) {                                    // 94
         if (err) {                                                                                  // 95
            console.warn('error', err);                                                              // 96
            failure(err);                                                                            // 97
         } else {                                                                                    //
            //   console.log('remove success');                                                      //
            success(); // remove record in orion                                                     // 100
         };                                                                                          //
      });                                                                                            //
   };                                                                                                //
}                                                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['vsivsi:orion-file-collection'] = {};

})();

//# sourceMappingURL=vsivsi_orion-file-collection.js.map
