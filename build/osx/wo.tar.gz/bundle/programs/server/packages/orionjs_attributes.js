(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var moment = Package['momentjs:moment'].moment;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/attributes.js                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
/**                                                                                                      //
 * Adds the option the set orionAttribute on SimpleSchema                                                //
 */                                                                                                      //
SimpleSchema.extendOptions({                                                                             // 4
  orionAttribute: Match.Optional(String),                                                                // 5
  orion: Match.Optional(Object)                                                                          // 6
});                                                                                                      //
                                                                                                         //
/**                                                                                                      //
 * Definition of the attributes object                                                                   //
 */                                                                                                      //
orion.attributes = {};                                                                                   // 12
                                                                                                         //
/**                                                                                                      //
 * Returns the schema for the attribute                                                                  //
 */                                                                                                      //
orion.attribute = function (name, schema, options) {                                                     // 17
  if (!_.has(orion.attributes, name)) {                                                                  // 18
    throw 'The attribute "' + name + '" does not exist';                                                 // 19
  }                                                                                                      //
  schema = schema || {};                                                                                 // 21
  options = options || {};                                                                               // 22
  var attributeSchema = orion.attributes[name].getSchema.call(this, options);                            // 23
  var override = {                                                                                       // 24
    orionAttribute: name,                                                                                // 25
    autoform: {                                                                                          // 26
      type: 'orion.' + name                                                                              // 27
    }                                                                                                    //
  };                                                                                                     //
  var attribute = orion.helpers.deepExtend(orion.helpers.deepExtend(schema, attributeSchema), override);
  return attribute;                                                                                      // 31
};                                                                                                       //
                                                                                                         //
/**                                                                                                      //
 * Returns proper tabular column for the attribute                                                       //
 */                                                                                                      //
orion.attributeColumn = function (name, key, title) {                                                    // 37
  var options = arguments.length <= 3 || arguments[3] === undefined ? {} : arguments[3];                 //
                                                                                                         //
  check(options, {                                                                                       // 38
    orderable: Match.Optional(Boolean)                                                                   // 39
  });                                                                                                    //
  var attributeDef = orion.attributes[name];                                                             // 41
                                                                                                         //
  if (attributeDef.orderable && options.orderable !== false) {                                           // 43
    options.orderable = true;                                                                            // 44
  }                                                                                                      //
                                                                                                         //
  return {                                                                                               // 47
    data: key,                                                                                           // 48
    title: title,                                                                                        // 49
    defaultContent: '',                                                                                  // 50
    orderable: !!options.orderable,                                                                      // 51
    render: function () {                                                                                // 52
      return '';                                                                                         // 53
    },                                                                                                   //
    createdCell: function (cell, cellData, rowData) {                                                    // 55
      var collection = rowData._collection();                                                            // 56
      var schema = rowData._collection().simpleSchema()._schema[key];                                    // 57
      var data = {                                                                                       // 58
        key: key,                                                                                        // 59
        value: cellData,                                                                                 // 60
        item: rowData,                                                                                   // 61
        collection: collection,                                                                          // 62
        schema: schema                                                                                   // 63
      };                                                                                                 //
      var template = ReactiveTemplates.get('attributePreview.' + name);                                  // 65
      Blaze.renderWithData(Template[template], data, cell);                                              // 66
    }                                                                                                    //
  };                                                                                                     //
};                                                                                                       //
                                                                                                         //
/**                                                                                                      //
 * Helper function to use arrays of attributes (Ex: array of images)                                     //
 */                                                                                                      //
orion.arrayOfAttribute = function (name, schema, options) {                                              // 74
  var subSchema = new SimpleSchema({                                                                     // 75
    item: orion.attribute(name, {                                                                        // 76
      autoform: {                                                                                        // 77
        label: false                                                                                     // 78
      }                                                                                                  //
    })                                                                                                   //
  });                                                                                                    //
  return orion.helpers.deepExtend(schema, {                                                              // 82
    type: [subSchema]                                                                                    // 83
  });                                                                                                    //
};                                                                                                       //
                                                                                                         //
/**                                                                                                      //
 * Creates a new attribute                                                                               //
 */                                                                                                      //
orion.attributes.registerAttribute = function (name, attribute) {                                        // 90
  check(name, String);                                                                                   // 91
  check(attribute, {                                                                                     // 92
    template: Match.Optional(String),                                                                    // 93
    columnTemplate: Match.Optional(String),                                                              // 94
    previewTemplate: Match.Optional(String),                                                             // 95
    getSchema: Function,                                                                                 // 96
    valueOut: Match.Optional(Function),                                                                  // 97
    valueIn: Match.Optional(Function),                                                                   // 98
    valueConverters: Match.Optional(Function),                                                           // 99
    contextAdjust: Match.Optional(Function),                                                             // 100
    orderable: Match.Optional(Boolean)                                                                   // 101
  });                                                                                                    //
                                                                                                         //
  if (attribute.template) {                                                                              // 104
    ReactiveTemplates.request('attribute.' + name, attribute.template);                                  // 105
  }                                                                                                      //
                                                                                                         //
  if (attribute.previewTemplate) {                                                                       // 108
    ReactiveTemplates.request('attributePreview.' + name, attribute.previewTemplate);                    // 109
  }                                                                                                      //
                                                                                                         //
  orion.attributes[name] = attribute;                                                                    // 112
                                                                                                         //
  if (Meteor.isClient && attribute.template) {                                                           // 114
    Tracker.autorun(function () {                                                                        // 115
      AutoForm.addInputType('orion.' + name, {                                                           // 116
        template: ReactiveTemplates.get('attribute.' + name),                                            // 117
        valueIn: attribute.valueIn,                                                                      // 118
        valueOut: attribute.valueOut,                                                                    // 119
        valueConverters: attribute.valueConverters,                                                      // 120
        contextAdjust: attribute.contextAdjust                                                           // 121
      });                                                                                                //
    });                                                                                                  //
  }                                                                                                      //
};                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-by/created-by.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdBy', {                                                        // 1
  previewTemplate: 'createdByPreview',                                                                   // 2
  getSchema: function (options) {                                                                        // 3
    return {                                                                                             // 4
      type: String,                                                                                      // 5
      index: 1,                                                                                          // 6
      autoform: {                                                                                        // 7
        omit: true                                                                                       // 8
      },                                                                                                 //
      optional: true,                                                                                    // 10
      autoValue: function () {                                                                           // 11
        if (this.isInsert) {                                                                             // 12
          return this.userId;                                                                            // 13
        } else if (this.isUpsert) {                                                                      //
          return { $setOnInsert: this.userId };                                                          // 15
        } else {                                                                                         //
          this.unset();                                                                                  // 17
        }                                                                                                //
      }                                                                                                  //
    };                                                                                                   //
  }                                                                                                      //
});                                                                                                      //
                                                                                                         //
if (Meteor.isServer) {                                                                                   // 24
  Meteor.publish('userProfileForCreatedByAttributeColumn', function (userId) {                           // 25
    check(userId, String);                                                                               // 26
    return Meteor.users.find({ _id: userId }, { fields: { profile: 1 } });                               // 27
  });                                                                                                    //
}                                                                                                        //
if (Meteor.isClient) {                                                                                   // 30
  ReactiveTemplates.onRendered('attributePreview.createdBy', function () {                               // 31
    this.subscribe('userProfileForCreatedByAttributeColumn', this.data.value);                           // 32
  });                                                                                                    //
  ReactiveTemplates.helpers('attributePreview.createdBy', {                                              // 34
    name: function () {                                                                                  // 35
      var user = Meteor.users.findOne(this.value);                                                       // 36
      return user && user.profile.name;                                                                  // 37
    }                                                                                                    //
  });                                                                                                    //
}                                                                                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-at/created-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdAt', {                                                        // 1
  previewTemplate: 'createdAtPreview',                                                                   // 2
  orderable: true,                                                                                       // 3
  getSchema: function (options) {                                                                        // 4
    return {                                                                                             // 5
      type: Date,                                                                                        // 6
      index: 1,                                                                                          // 7
      autoform: {                                                                                        // 8
        omit: true                                                                                       // 9
      },                                                                                                 //
      autoValue: function () {                                                                           // 11
        if (this.isInsert) {                                                                             // 12
          return new Date();                                                                             // 13
        } else if (this.isUpsert) {                                                                      //
          return { $setOnInsert: new Date() };                                                           // 15
        } else {                                                                                         //
          this.unset();                                                                                  // 17
        }                                                                                                //
      }                                                                                                  //
    };                                                                                                   //
  }                                                                                                      //
});                                                                                                      //
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 24
  ReactiveTemplates.helpers('attributePreview.createdAt', {                                              // 25
    date: function () {                                                                                  // 26
      return this.value && moment(this.value).format('LLL');                                             // 27
    }                                                                                                    //
  });                                                                                                    //
}                                                                                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/updated-by/updated-by.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('updatedBy', {                                                        // 1
  previewTemplate: 'updatedByPreview',                                                                   // 2
  getSchema: function (options) {                                                                        // 3
    return {                                                                                             // 4
      type: String,                                                                                      // 5
      index: 1,                                                                                          // 6
      autoform: {                                                                                        // 7
        omit: true                                                                                       // 8
      },                                                                                                 //
      autoValue: function () {                                                                           // 10
        if (this.isUpdate || this.isInsert) {                                                            // 11
          return this.userId;                                                                            // 12
        } else if (this.isUpsert) {                                                                      //
          return { $setOnInsert: this.userId };                                                          // 14
        } else {                                                                                         //
          this.unset();                                                                                  // 16
        }                                                                                                //
      }                                                                                                  //
    };                                                                                                   //
  }                                                                                                      //
});                                                                                                      //
                                                                                                         //
if (Meteor.isServer) {                                                                                   // 23
  Meteor.publish('userProfileForUpdatedByAttributeColumn', function (userId) {                           // 24
    check(userId, String);                                                                               // 25
    return Meteor.users.find({ _id: userId }, { fields: { profile: 1 } });                               // 26
  });                                                                                                    //
}                                                                                                        //
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 30
  ReactiveTemplates.onRendered('attributePreview.updatedBy', function () {                               // 31
    this.subscribe('userProfileForUpdatedByAttributeColumn', this.data.value);                           // 32
  });                                                                                                    //
  ReactiveTemplates.helpers('attributePreview.updatedBy', {                                              // 34
    name: function () {                                                                                  // 35
      var user = Meteor.users.findOne(this.value);                                                       // 36
      return user && user.profile.name;                                                                  // 37
    }                                                                                                    //
  });                                                                                                    //
}                                                                                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/updated-at/updated-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('updatedAt', {                                                        // 1
  previewTemplate: 'updatedAtPreview',                                                                   // 2
  orderable: true,                                                                                       // 3
  getSchema: function (options) {                                                                        // 4
    return {                                                                                             // 5
      type: Date,                                                                                        // 6
      index: 1,                                                                                          // 7
      autoform: {                                                                                        // 8
        omit: true                                                                                       // 9
      },                                                                                                 //
      autoValue: function () {                                                                           // 11
        if (this.isUpdate || this.isInsert) {                                                            // 12
          return new Date();                                                                             // 13
        } else if (this.isUpsert) {                                                                      //
          return { $setOnInsert: new Date() };                                                           // 15
        } else {                                                                                         //
          this.unset();                                                                                  // 17
        }                                                                                                //
      }                                                                                                  //
    };                                                                                                   //
  }                                                                                                      //
});                                                                                                      //
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 24
  ReactiveTemplates.helpers('attributePreview.updatedAt', {                                              // 25
    date: function () {                                                                                  // 26
      return this.value && moment(this.value).format('LLL');                                             // 27
    }                                                                                                    //
  });                                                                                                    //
}                                                                                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:attributes'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_attributes.js.map
