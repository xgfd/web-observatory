(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var _ = Package.underscore._;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/init.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Init the entities variable                                                                                         //
 */                                                                                                                   //
orion.collections = {};                                                                                               // 4
                                                                                                                      //
orion.collections.hooks = {                                                                                           // 6
  onCreated: []                                                                                                       // 7
};                                                                                                                    //
                                                                                                                      //
orion.collections.onCreated = function (cb) {                                                                         // 10
  this.hooks.onCreated.push(cb);                                                                                      // 11
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Request the default templates using options                                                                        //
 */                                                                                                                   //
Options.init('collectionsDefaultIndexTemplate');                                                                      // 17
Options.init('collectionsDefaultCreateTemplate');                                                                     // 18
Options.init('collectionsDefaultUpdateTemplate');                                                                     // 19
Options.init('collectionsDefaultDeleteTemplate');                                                                     // 20
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/new.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.list = {};                                                                                          // 1
                                                                                                                      //
/**                                                                                                                   //
 * Collection definition, it overrides Mongo.Collection                                                               //
 */                                                                                                                   //
orion.collection = function (name, options) {                                                                         // 6
  check(name, String);                                                                                                // 7
  check(options, Object);                                                                                             // 8
                                                                                                                      //
  var collection = new Mongo.Collection(name, options);                                                               // 10
                                                                                                                      //
  options = _.extend({                                                                                                // 12
    name: name,                                                                                                       // 13
    routePath: name,                                                                                                  // 14
    pluralName: name,                                                                                                 // 15
    singularName: name,                                                                                               // 16
    title: name[0].toUpperCase() + name.slice(1)                                                                      // 17
  }, options);                                                                                                        //
                                                                                                                      //
  collection = _.extend(collection, options);                                                                         // 20
                                                                                                                      //
  for (var i = 0, N = orion.collections.hooks.onCreated.length; i < N; i++) {                                         // 22
    orion.collections.hooks.onCreated[i].call(collection);                                                            // 23
  }                                                                                                                   //
                                                                                                                      //
  collection.helpers({                                                                                                // 26
    _collection: function () {                                                                                        // 27
      return collection;                                                                                              // 28
    }                                                                                                                 //
  });                                                                                                                 //
                                                                                                                      //
  orion.collections.list[name] = collection;                                                                          // 32
  return collection;                                                                                                  // 33
};                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/permissions.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function () {                                                                             // 1
  var self = this;                                                                                                    // 2
                                                                                                                      //
  var allow = !this.dontAllowByDefault;                                                                               // 4
                                                                                                                      //
  /**                                                                                                                 //
   * Collection permissions                                                                                           //
   */                                                                                                                 //
  Roles.registerAction('collections.' + this.name + '.index', allow);                                                 // 9
  Roles.registerAction('collections.' + this.name + '.showCreate', allow);                                            // 10
  Roles.registerAction('collections.' + this.name + '.showUpdate', allow);                                            // 11
  Roles.registerAction('collections.' + this.name + '.showRemove', allow);                                            // 12
  Roles.registerHelper('collections.' + this.name + '.indexFilter', allow && {});                                     // 13
                                                                                                                      //
  this.attachRoles('collections.' + this.name);                                                                       // 15
                                                                                                                      //
  if (Meteor.isClient) {                                                                                              // 17
    this.canIndex = function () {                                                                                     // 18
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.index');                         // 19
    };                                                                                                                //
    this.canShowCreate = function () {                                                                                // 21
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showCreate');                    // 22
    };                                                                                                                //
    this.getHiddenFields = function () {                                                                              // 24
      var docId = RouterLayer.getParam('_id');                                                                        // 25
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'collections.' + self.name + '.forbiddenFields', docId));
    };                                                                                                                //
    this.helpers({                                                                                                    // 28
      canShowUpdate: function () {                                                                                    // 29
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showUpdate', this);            // 30
      },                                                                                                              //
      canShowRemove: function () {                                                                                    // 32
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showRemove', this);            // 33
      }                                                                                                               //
    });                                                                                                               //
  }                                                                                                                   //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/admin.js                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function () {                                                                             // 1
  var self = this;                                                                                                    // 2
                                                                                                                      //
  /**                                                                                                                 //
   * Request a template for the collection                                                                            //
   */                                                                                                                 //
  ReactiveTemplates.request('collections.' + self.name + '.index', Options.get('collectionsDefaultIndexTemplate'));   // 7
                                                                                                                      //
  /**                                                                                                                 //
   * Register the index route                                                                                         //
   */                                                                                                                 //
  RouterLayer.route('/admin/' + self.routePath, {                                                                     // 12
    layout: 'layout',                                                                                                 // 13
    template: 'collections.' + self.name + '.index',                                                                  // 14
    name: 'collections.' + self.name + '.index',                                                                      // 15
    reactiveTemplates: true                                                                                           // 16
  });                                                                                                                 //
  self.indexPath = function () {                                                                                      // 18
    return RouterLayer.pathFor('collections.' + self.name + '.index');                                                // 19
  };                                                                                                                  //
                                                                                                                      //
  /**                                                                                                                 //
   * Ensure user is logged in                                                                                         //
   */                                                                                                                 //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.index');                                            // 25
                                                                                                                      //
  /**                                                                                                                 //
   * Request a template for the collection create                                                                     //
   */                                                                                                                 //
  ReactiveTemplates.request('collections.' + self.name + '.create', Options.get('collectionsDefaultCreateTemplate'));
                                                                                                                      //
  /**                                                                                                                 //
   * Register the create route                                                                                        //
   */                                                                                                                 //
  RouterLayer.route('/admin/' + self.routePath + '/create', {                                                         // 35
    layout: 'layout',                                                                                                 // 36
    template: 'collections.' + self.name + '.create',                                                                 // 37
    name: 'collections.' + self.name + '.create',                                                                     // 38
    reactiveTemplates: true                                                                                           // 39
  });                                                                                                                 //
  self.createPath = function () {                                                                                     // 41
    return RouterLayer.pathFor('collections.' + self.name + '.create');                                               // 42
  };                                                                                                                  //
                                                                                                                      //
  /**                                                                                                                 //
   * Ensure user is logged in                                                                                         //
   */                                                                                                                 //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.create');                                           // 48
                                                                                                                      //
  /**                                                                                                                 //
   * Request a template for the collection update                                                                     //
   */                                                                                                                 //
  ReactiveTemplates.request('collections.' + self.name + '.update', Options.get('collectionsDefaultUpdateTemplate'));
                                                                                                                      //
  /**                                                                                                                 //
   * Register the update route                                                                                        //
   */                                                                                                                 //
  RouterLayer.route('/admin/' + self.routePath + '/:_id', {                                                           // 58
    layout: 'layout',                                                                                                 // 59
    template: 'collections.' + self.name + '.update',                                                                 // 60
    name: 'collections.' + self.name + '.update',                                                                     // 61
    reactiveTemplates: true                                                                                           // 62
  });                                                                                                                 //
  self.updatePath = function (item) {                                                                                 // 64
    var options = item;                                                                                               // 65
    if (_.isString(item)) {                                                                                           // 66
      options = { _id: item };                                                                                        // 67
    }                                                                                                                 //
    return RouterLayer.pathFor('collections.' + self.name + '.update', options);                                      // 69
  };                                                                                                                  //
                                                                                                                      //
  /**                                                                                                                 //
   * Ensure user is logged in                                                                                         //
   */                                                                                                                 //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.update');                                           // 75
                                                                                                                      //
  /**                                                                                                                 //
   * Request a template for the collection delete                                                                     //
   */                                                                                                                 //
  ReactiveTemplates.request('collections.' + self.name + '.delete', Options.get('collectionsDefaultDeleteTemplate'));
                                                                                                                      //
  /**                                                                                                                 //
   * Register the delete route                                                                                        //
   */                                                                                                                 //
  RouterLayer.route('/admin/' + self.routePath + '/:_id/delete', {                                                    // 85
    layout: 'layout',                                                                                                 // 86
    template: 'collections.' + self.name + '.delete',                                                                 // 87
    name: 'collections.' + self.name + '.delete',                                                                     // 88
    reactiveTemplates: true                                                                                           // 89
  });                                                                                                                 //
  this.deletePath = function (item) {                                                                                 // 91
    var options = item;                                                                                               // 92
    if (_.isString(item)) {                                                                                           // 93
      options = { _id: item };                                                                                        // 94
    }                                                                                                                 //
    return RouterLayer.pathFor('collections.' + self.name + '.delete', options);                                      // 96
  };                                                                                                                  //
                                                                                                                      //
  /**                                                                                                                 //
   * Ensure user is logged in                                                                                         //
   */                                                                                                                 //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.delete');                                           // 102
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/publications.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function () {                                                                             // 1
  var self = this;                                                                                                    // 2
  Meteor.publish('adminGetOne.' + this.name, function (_id) {                                                         // 3
    check(_id, String);                                                                                               // 4
    return self.find(_id);                                                                                            // 5
  }, { is_auto: true });                                                                                              //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:collections'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_collections.js.map
