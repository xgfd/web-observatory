(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

/* Package-scope variables */
var detectLanguage;

(function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/orionjs_lang-en/init.js                                            //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
i18n.setDefaultLanguage('en');                                                 // 1
i18n.showMissing('[no translation for "<%= label %>" in <%= language %>]');    // 2
                                                                               // 3
if (Meteor.isClient) {                                                         // 4
  /**                                                                          // 5
   * Detects and set the language                                              // 6
   */                                                                          // 7
  detectLanguage = function() {                                                // 8
    var language = window.navigator.userLanguage || window.navigator.language;
    language = language.split('-')[0];                                         // 10
    i18n.setLanguage(language);                                                // 11
    T9n.setLanguage(language);                                                 // 12
  };                                                                           // 13
                                                                               // 14
  /**                                                                          // 15
   * Detects and set the language on startup                                   // 16
   */                                                                          // 17
  Meteor.startup(function () {                                                 // 18
    detectLanguage();                                                          // 19
  });                                                                          // 20
}                                                                              // 21
                                                                               // 22
/////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/orionjs_lang-en/en.js                                              //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
i18n.map('en', {                                                               // 1
  global: {                                                                    // 2
    save: 'Save',                                                              // 3
    create: 'Create',                                                          // 4
    logout: 'Logout',                                                          // 5
    back: 'Back',                                                              // 6
    cancel: 'Cancel',                                                          // 7
    delete: 'Delete',                                                          // 8
    confirm: 'Confirm',                                                        // 9
    choose: 'Choose',                                                          // 10
    noPermission: 'You have no permissions',                                   // 11
    passwordNotMatch: 'Passwords doesn\'t match',                              // 12
    optional: 'Optional'                                                       // 13
  },                                                                           // 14
  accounts: {                                                                  // 15
    schema: {                                                                  // 16
      emails: {                                                                // 17
        title: 'Emails',                                                       // 18
        address: 'Address',                                                    // 19
        verified: 'Verified'                                                   // 20
      },                                                                       // 21
      password: {                                                              // 22
        title: 'Password',                                                     // 23
        new: 'New Password',                                                   // 24
        confirm: 'Confirm Password'                                            // 25
      },                                                                       // 26
      profile: {                                                               // 27
        name: 'Name'                                                           // 28
      }                                                                        // 29
    },                                                                         // 30
    index: {                                                                   // 31
      title: 'Accounts',                                                       // 32
      noName: 'No Name',                                                       // 33
      actions: {                                                               // 34
        edit: 'Edit',                                                          // 35
        sendEnrollmentEmail: 'Send Enrollment Email'                           // 36
      },                                                                       // 37
      tableTitles: {                                                           // 38
        name: 'Name',                                                          // 39
        services: 'Login method',                                              // 40
        email: 'Email',                                                        // 41
        roles: 'Roles',                                                        // 42
        actions: 'Actions'                                                     // 43
      }                                                                        // 44
    },                                                                         // 45
    update: {                                                                  // 46
      title: 'Update Account',                                                 // 47
      messages: {                                                              // 48
        noPermissions: 'You have no permissions to edit this user'             // 49
      },                                                                       // 50
      sections: {                                                              // 51
        profile: {                                                             // 52
          title: 'Profile'                                                     // 53
        },                                                                     // 54
        roles: {                                                               // 55
          title: 'Roles',                                                      // 56
          selectRoles: 'Select user roles'                                     // 57
        },                                                                     // 58
        changePassword: {                                                      // 59
          title: 'Change Password'                                             // 60
        },                                                                     // 61
        deleteUser: {                                                          // 62
          title: 'Danger Ahead',                                               // 63
          advice: 'Deleting users can cause problems.',                        // 64
          button: 'Delete User'                                                // 65
        }                                                                      // 66
      }                                                                        // 67
    },                                                                         // 68
    myAccount: {                                                               // 69
      title: 'My Account',                                                     // 70
    },                                                                         // 71
    create: {                                                                  // 72
      title: 'Create a User',                                                  // 73
      createInvitation: 'Create invitation',                                   // 74
      createUserNow: 'Create user now',                                        // 75
      inviteOther: 'Invite Other',                                             // 76
      selectRoles: 'Select new user roles',                                    // 77
      email: 'Email',                                                          // 78
      messages: {                                                              // 79
        successfullyCreated: 'Invitation created successfully'                 // 80
      }                                                                        // 81
    },                                                                         // 82
    changePassword: {                                                          // 83
      title: 'Change Password',                                                // 84
    },                                                                         // 85
    updateProfile: {                                                           // 86
      title: 'Update Profile',                                                 // 87
    },                                                                         // 88
    register: {                                                                // 89
      title: 'Register',                                                       // 90
      registerButton: 'Register',                                              // 91
      fields: {                                                                // 92
        email: 'Email',                                                        // 93
        name: 'Name',                                                          // 94
        password: 'Password',                                                  // 95
        confirmPassword: 'Password (again)'                                    // 96
      },                                                                       // 97
      messages: {                                                              // 98
        invalidEmail: 'Invalid Email',                                         // 99
        invalidInvitationCode: 'Invalid invitation code',                      // 100
      }                                                                        // 101
    }                                                                          // 102
  },                                                                           // 103
  collections: {                                                               // 104
    create: {                                                                  // 105
      title: 'Create a {$1}'                                                   // 106
    },                                                                         // 107
    update: {                                                                  // 108
      title: 'Update {$1}'                                                     // 109
    },                                                                         // 110
    delete: {                                                                  // 111
      title: 'Delete {$1}',                                                    // 112
      confirmQuestion: 'Are you sure you wan\'t to delete this {$1}?'          // 113
    },                                                                         // 114
    common: {                                                                  // 115
      defaultPluralName: 'items',                                              // 116
      defaultSingularName: 'item',                                             // 117
    }                                                                          // 118
  },                                                                           // 119
  config: {                                                                    // 120
    update: {                                                                  // 121
      title: 'Config',                                                         // 122
    }                                                                          // 123
  },                                                                           // 124
  dictionary: {                                                                // 125
    update: {                                                                  // 126
      title: 'Dictionary'                                                      // 127
    }                                                                          // 128
  },                                                                           // 129
  filesystem: {                                                                // 130
    messages: {                                                                // 131
      notFound_id: 'File not found [{$i}]',                                    // 132
      errorUploading: 'Error uploading file',                                  // 133
      errorRemoving: 'Error removing file',                                    // 134
    }                                                                          // 135
  },                                                                           // 136
  pages: {                                                                     // 137
    schema: {                                                                  // 138
      title: 'Title',                                                          // 139
      url: 'Url',                                                              // 140
    },                                                                         // 141
    index: {                                                                   // 142
      title: 'Pages',                                                          // 143
    },                                                                         // 144
    create: {                                                                  // 145
      title: 'Create page',                                                    // 146
      chooseTemplate: 'Choose Template'                                        // 147
    },                                                                         // 148
    update: {                                                                  // 149
      title: 'Update page',                                                    // 150
    },                                                                         // 151
    delete: {                                                                  // 152
      title: 'Delete page',                                                    // 153
      confirmQuestion: 'Are you sure you wan\'t to delete this page?'          // 154
    }                                                                          // 155
  },                                                                           // 156
  attributes: {                                                                // 157
    users: {                                                                   // 158
      pluralName: 'users',                                                     // 159
      singularName: 'user',                                                    // 160
    },                                                                         // 161
    file: {                                                                    // 162
      choose: 'Choose file',                                                   // 163
      noFile: 'No file',                                                       // 164
    },                                                                         // 165
    image: {                                                                   // 166
      choose: 'Choose image'                                                   // 167
    },                                                                         // 168
    images: {                                                                  // 169
      choose: 'Choose the images',                                             // 170
      clickToRemove: 'Click to remove'                                         // 171
    }                                                                          // 172
  },                                                                           // 173
  tabular: {                                                                   // 174
    search: 'Search:',                                                         // 175
    info: 'Showing _START_ to _END_ of _TOTAL_ entries',                       // 176
    infoEmpty: 'Showing 0 to 0 of 0 entries',                                  // 177
    lengthMenu: 'Show _MENU_ entries',                                         // 178
    emptyTable: 'No data available in table',                                  // 179
    paginate: {                                                                // 180
      first: 'First',                                                          // 181
      previous: 'Previous',                                                    // 182
      next: 'Next',                                                            // 183
      last: 'Last',                                                            // 184
    }                                                                          // 185
  }                                                                            // 186
});                                                                            // 187
                                                                               // 188
/////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:lang-en'] = {};

})();

//# sourceMappingURL=orionjs_lang-en.js.map
