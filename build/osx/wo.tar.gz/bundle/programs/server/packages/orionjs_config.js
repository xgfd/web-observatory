(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Inject = Package['meteorhacks:inject-initial'].Inject;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_config/config.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Definition of the config object                                                                                    //
 */                                                                                                                   //
orion.config = {                                                                                                      // 4
  collection: new Meteor.Collection('orion_config'),                                                                  // 5
  object: {}                                                                                                          // 6
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Allows to set some fields on simple schema                                                                         //
 */                                                                                                                   //
SimpleSchema.extendOptions({                                                                                          // 12
  category: Match.Optional(String),                                                                                   // 13
  'public': Match.Optional(Boolean),                                                                                  // 14
  secret: Match.Optional(Boolean),                                                                                    // 15
  name: Match.Optional(String)                                                                                        // 16
});                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   //
 * To get reactively if the config is active                                                                          //
 */                                                                                                                   //
orion.config._isActiveDependency = new Tracker.Dependency();                                                          // 22
orion.config._isActive = false;                                                                                       // 23
orion.config.isActive = function () {                                                                                 // 24
  this._isActiveDependency.depend();                                                                                  // 25
  return this._isActive;                                                                                              // 26
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Register the action for the permissions                                                                            //
 */                                                                                                                   //
Roles.registerAction('config.update', true);                                                                          // 32
                                                                                                                      //
/**                                                                                                                   //
 * Permissions for the dictionary.                                                                                    //
 */                                                                                                                   //
orion.config.collection.allow({                                                                                       // 37
  /**                                                                                                                 //
   * No one can insert a config object                                                                                //
   * becouse it only uses one and its created                                                                         //
   * automatically.                                                                                                   //
   */                                                                                                                 //
  'insert': function (userId, doc) {                                                                                  // 43
    return false;                                                                                                     // 44
  },                                                                                                                  //
  /**                                                                                                                 //
   * No one can remove a config object                                                                                //
   * becouse it only uses one.                                                                                        //
   */                                                                                                                 //
  'remove': function (userId, doc) {                                                                                  // 50
    return false;                                                                                                     // 51
  }                                                                                                                   //
});                                                                                                                   //
                                                                                                                      //
orion.config.collection.allow({                                                                                       // 55
  'update': function (userId, doc, fields, modifier) {                                                                // 56
    return Roles.allow(userId, 'config.update', userId, doc, fields, modifier);                                       // 57
  }                                                                                                                   //
});                                                                                                                   //
                                                                                                                      //
orion.config.collection.deny({                                                                                        // 61
  'update': function (userId, doc, fields, modifier) {                                                                // 62
    return Roles.deny(userId, 'config.update', userId, doc, fields, modifier);                                        // 63
  }                                                                                                                   //
});                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   //
 * Function to add a config.                                                                                          //
 * This just modifies the schema of the config object                                                                 //
 * and adds the form in the admin panel.                                                                              //
 */                                                                                                                   //
orion.config.add = function (name, category, options) {                                                               // 72
  var newSchema = this.collection.simpleSchema() && _.clone(this.collection.simpleSchema()._schema) || {};            // 73
                                                                                                                      //
  newSchema[name] = _.extend({                                                                                        // 75
    type: String,                                                                                                     // 76
    secret: false,                                                                                                    // 77
    label: name,                                                                                                      // 78
    'public': false,                                                                                                  // 79
    category: category,                                                                                               // 80
    name: name                                                                                                        // 81
  }, options || {});                                                                                                  //
                                                                                                                      //
  if (newSchema[name].secret) {                                                                                       // 84
    newSchema[name].autoform = {                                                                                      // 85
      type: 'password',                                                                                               // 86
      'data-type': 'secret'                                                                                           // 87
    };                                                                                                                //
  }                                                                                                                   //
                                                                                                                      //
  this.collection.attachSchema(new SimpleSchema(newSchema));                                                          // 91
                                                                                                                      //
  if (!this._isActive) {                                                                                              // 93
    this._isActive = true;                                                                                            // 94
    this._isActiveDependency.changed();                                                                               // 95
  }                                                                                                                   //
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Returns the value of the config.                                                                                   //
 * If the config doesn't exists it                                                                                    //
 * returns the defaultValue                                                                                           //
 */                                                                                                                   //
orion.config.get = function (path, defaultValue) {                                                                    // 104
  // Sets empty string to avoid problems on templates                                                                 //
  defaultValue = !defaultValue || defaultValue instanceof Spacebars.kw ? '' : defaultValue;                           // 106
  return orion.helpers.searchObjectWithDots(this.object, path) || defaultValue;                                       // 107
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Returns the public options                                                                                         //
 */                                                                                                                   //
orion.config.getPublicFields = function () {                                                                          // 113
  var atts = this.collection.simpleSchema() && _.where(this.collection.simpleSchema()._schema, { 'public': true });   // 114
  return atts && _.pluck(atts, 'name');                                                                               // 115
};                                                                                                                    //
                                                                                                                      //
/**                                                                                                                   //
 * Returns fields that are not public                                                                                 //
 */                                                                                                                   //
orion.config.getPrivateFields = function () {                                                                         // 121
  var atts = this.collection.simpleSchema() && _.where(this.collection.simpleSchema()._schema, { 'public': false });  // 122
  return atts && _.pluck(atts, 'name');                                                                               // 123
};                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_config/admin.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Init the template name variable                                                                                    //
 */                                                                                                                   //
ReactiveTemplates.request('configUpdate');                                                                            // 4
                                                                                                                      //
/**                                                                                                                   //
 * Register the route                                                                                                 //
 */                                                                                                                   //
RouterLayer.route('/admin/config', {                                                                                  // 9
  layout: 'layout',                                                                                                   // 10
  template: 'configUpdate',                                                                                           // 11
  name: 'config.update',                                                                                              // 12
  reactiveTemplates: true                                                                                             // 13
});                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   //
 * Ensure user is logged in                                                                                           //
 */                                                                                                                   //
orion.accounts.addProtectedRoute('config.update');                                                                    // 19
                                                                                                                      //
/**                                                                                                                   //
 * Register the link                                                                                                  //
 */                                                                                                                   //
if (Meteor.isClient) {                                                                                                // 24
  Tracker.autorun(function () {                                                                                       // 25
    if (!orion.config.isActive()) return;                                                                             // 26
    orion.links.add({                                                                                                 // 27
      index: 100,                                                                                                     // 28
      identifier: 'config-update',                                                                                    // 29
      title: i18n('config.update.title'),                                                                             // 30
      routeName: 'config.update',                                                                                     // 31
      activeRouteRegex: 'config',                                                                                     // 32
      permission: 'config.update'                                                                                     // 33
    });                                                                                                               //
  });                                                                                                                 //
}                                                                                                                     //
                                                                                                                      //
/**                                                                                                                   //
 * Create the template helpers for a dictionary                                                                       //
 */                                                                                                                   //
if (Meteor.isClient) {                                                                                                // 41
                                                                                                                      //
  ReactiveTemplates.onCreated('configUpdate', function () {                                                           // 43
    this.subscribe('orion_config');                                                                                   // 44
  });                                                                                                                 //
                                                                                                                      //
  ReactiveTemplates.onRendered('configUpdate', function () {                                                          // 47
    var categories = _.uniq(_.pluck(orion.config.collection.simpleSchema()._schema, 'category'));                     // 48
    var defaultCategory = categories && categories[0];                                                                // 49
    Session.set('configUpdateCurrentCategory', defaultCategory);                                                      // 50
  });                                                                                                                 //
                                                                                                                      //
  ReactiveTemplates.events('configUpdate', {                                                                          // 53
    'click [data-category]': function (event) {                                                                       // 54
      var newCategory = $(event.currentTarget).attr('data-category');                                                 // 55
      Session.set('configUpdateCurrentCategory', newCategory);                                                        // 56
    }                                                                                                                 //
  });                                                                                                                 //
                                                                                                                      //
  ReactiveTemplates.helpers('configUpdate', {                                                                         // 60
    getDoc: function () {                                                                                             // 61
      return orion.config.collection.findOne();                                                                       // 62
    },                                                                                                                //
    getFields: function () {                                                                                          // 64
      var currentCategory = Session.get('configUpdateCurrentCategory');                                               // 65
      return _.pluck(_.where(orion.config.collection.simpleSchema()._schema, { category: currentCategory }), 'name');
    },                                                                                                                //
    getCategories: function () {                                                                                      // 68
      return _.uniq(_.pluck(orion.config.collection.simpleSchema()._schema, 'category'));                             // 69
    }                                                                                                                 //
  });                                                                                                                 //
}                                                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_config/config_server.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Restarts the server after updates                                                                                  //
 */                                                                                                                   //
orion.config.collection.after.update(function (userId, doc, fieldNames, modifier, options) {                          // 4
  // Timeout is necessary to no enter a infinit loop of restarts                                                      //
  Meteor.setTimeout(function () {                                                                                     // 6
    console.log('Updating Orion config');                                                                             // 7
    process.exit();                                                                                                   // 8
  }, 500);                                                                                                            //
});                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   //
 * Creates one object in the config collection                                                                        //
 */                                                                                                                   //
if (orion.config.collection.find(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {}).count() === 0) {    // 15
  orion.config.collection.insert(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {}, function () {       // 16
    console.log("Orion config initialized");                                                                          // 17
  });                                                                                                                 //
}                                                                                                                     //
                                                                                                                      //
/**                                                                                                                   //
 * Publications of the config. Only for admins                                                                        //
 */                                                                                                                   //
Meteor.publish('orion_config', function () {                                                                          // 24
  if (!this.userId) {                                                                                                 // 25
    return [];                                                                                                        // 26
  }                                                                                                                   //
  if (Roles.userHasPermission(this.userId, 'config.update')) {                                                        // 28
    return orion.config.collection.find(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {});             // 29
  }                                                                                                                   //
});                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   //
 * Get the config from the database only once                                                                         //
 */                                                                                                                   //
orion.config.object = orion.config.collection.findOne(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {});
                                                                                                                      //
/**                                                                                                                   //
 * Send the data to the client (only public values).                                                                  //
 * It uses the injection method (meteorhacks:inject-initial) not                                                      //
 * the publish/subcribe, because this is not meant to be reactive                                                     //
 * and the values should be on the client when it starts.                                                             //
 */                                                                                                                   //
Meteor.startup(function () {                                                                                          // 44
  if (!orion.config.getPublicFields()) {                                                                              // 45
    Inject.obj('orion.config', {});                                                                                   // 46
    return;                                                                                                           // 47
  }                                                                                                                   //
                                                                                                                      //
  var fields = { _id: 0 };                                                                                            // 50
                                                                                                                      //
  //we needs to add in private fields so we can tell our query to not return them                                     //
  //so that private fields won't be injected and remain secure                                                        //
  _.each(orion.config.getPrivateFields(), function (field) {                                                          // 54
    fields[field] = 0;                                                                                                // 55
  });                                                                                                                 //
                                                                                                                      //
  var config = orion.config.collection.findOne(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {}, { fields: fields });
                                                                                                                      //
  Inject.obj('orion.config', config);                                                                                 // 60
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:config'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_config.js.map
