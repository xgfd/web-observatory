(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:filesystem'].orion;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Colibri;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_image-attribute/attribute.js                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var subSchema = new SimpleSchema({                                   // 1
  url: {                                                             // 2
    type: String                                                     // 3
  },                                                                 //
  fileId: {                                                          // 5
    type: String                                                     // 6
  },                                                                 //
  info: {                                                            // 8
    type: Object,                                                    // 9
    optional: true                                                   // 10
  },                                                                 //
  'info.width': {                                                    // 12
    type: Number,                                                    // 13
    optional: true                                                   // 14
  },                                                                 //
  'info.height': {                                                   // 16
    type: Number,                                                    // 17
    optional: true                                                   // 18
  },                                                                 //
  'info.backgroundColor': {                                          // 20
    type: String,                                                    // 21
    optional: true                                                   // 22
  },                                                                 //
  'info.primaryColor': {                                             // 24
    type: String,                                                    // 25
    optional: true                                                   // 26
  },                                                                 //
  'info.secondaryColor': {                                           // 28
    type: String,                                                    // 29
    optional: true                                                   // 30
  }                                                                  //
});                                                                  //
                                                                     //
orion.attributes.registerAttribute('image', {                        // 34
  template: 'orionAttributesImageUpload',                            // 35
  previewTemplate: 'orionAttributesImageUploadColumn',               // 36
  getSchema: function (options) {                                    // 37
    return {                                                         // 38
      type: subSchema                                                // 39
    };                                                               //
  },                                                                 //
  valueOut: function () {                                            // 42
    return Session.get('image' + this.attr('data-schema-key'));      // 43
  }                                                                  //
});                                                                  //
                                                                     //
orion.attributes.registerAttribute('images', {                       // 47
  template: 'orionAttributesImagesUpload',                           // 48
  previewTemplate: 'orionAttributesImagesUploadColumn',              // 49
  getSchema: function (options) {                                    // 50
    return {                                                         // 51
      type: [subSchema]                                              // 52
    };                                                               //
  },                                                                 //
  valueOut: function () {                                            // 55
    return Session.get('images' + this.attr('data-schema-key'));     // 56
  }                                                                  //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:image-attribute'] = {
  Colibri: Colibri
};

})();

//# sourceMappingURL=orionjs_image-attribute.js.map
