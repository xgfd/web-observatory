(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/config.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 11/01/2016.                                      //
 */                                                                    //
                                                                       //
Meteor.startup(function () {                                           // 5
    var settings = Meteor.settings;                                    // 6
                                                                       //
    //create admin                                                     //
    if (!settings.admin) {                                             // 9
        settings.admin = { name: 'admin', username: 'admin', email: 'admin@webobservatory.org', password: 'admin' };
    }                                                                  //
                                                                       //
    if (!Accounts.findUserByUsername(settings.admin.username)) {       // 13
        var xgfdId = Accounts.createUser({                             // 14
            profile: {                                                 // 15
                name: settings.admin.name                              // 16
            },                                                         //
            username: settings.admin.username,                         // 18
            email: settings.admin.email,                               // 19
            password: settings.admin.password                          // 20
        });                                                            //
                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);             // 23
        Roles.addUserToRoles(xgfdId, ["admin"]);                       // 24
    }                                                                  //
                                                                       //
    // 1. Set up stmp                                                  //
    //   your_server would be something like 'smtp.gmail.com'          //
    //   and your_port would be a number like 25                       //
                                                                       //
    process.env.MAIL_URL = 'smtp://' +                                 // 31
    //encodeURIComponent(your_username) + ':' +                        //
    //encodeURIComponent(your_password) + '@' +                        //
    encodeURIComponent(settings.smtp);                                 // 34
                                                                       //
    // 2. Format the email                                             //
    //...                                                              //
                                                                       //
    // 3.  Send email when account is created                          //
    //...                                                              //
    // Add Facebook configuration entry                                //
                                                                       //
    if (settings.facebook) {                                           // 43
        ServiceConfiguration.configurations.update({ "service": "facebook" }, {
            $set: {                                                    // 47
                "appId": settings.facebook.appId,                      // 48
                "secret": settings.facebook.secret                     // 49
            }                                                          //
        }, { upsert: true });                                          //
    }                                                                  //
                                                                       //
    // Add GitHub configuration entry                                  //
    if (settings.github) {                                             // 57
        ServiceConfiguration.configurations.update({ "service": "github" }, {
            $set: {                                                    // 61
                "clientId": settings.github.clientId,                  // 62
                "secret": settings.github.secret                       // 63
            }                                                          //
        }, { upsert: true });                                          //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=config.js.map
