(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/groups.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 25/12/2015.                                      //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 5
    addToGroup: function (userId, groupId) {                           // 6
        check(userId, String);                                         // 7
        check(groupId, String);                                        // 8
        return Groups.update(groupId, { $addToSet: { contentWhiteList: userId } });
    },                                                                 //
    removeFromGroup: function (userId, groupId) {                      // 11
        check(userId, String);                                         // 12
        check(groupId, String);                                        // 13
        Groups.update(groupId, { $pull: { contentWhiteList: userId } });
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=groups.js.map
