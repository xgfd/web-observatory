(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/creative_work.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 26/12/2015.                                      //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 5
    //datasetInsert: function (datasetAttributes) {                    //
    //    check(this.userId, String);                                  //
    //    check(datasetAttributes, {                                   //
    //        name: String,                                            //
    //        //url: String                                            //
    //    });                                                          //
    //                                                                 //
    //    let errors = validateDataset(datasetAttributes);             //
    //    if (errors.name || errors.distribution)                      //
    //        throw new Meteor.Error('invalid-dataset', "You must set a name and distribution for your dataset");
    //                                                                 //
    //    //let datasetWithSameLink = Datasets.findOne({"distribution.url": datasetAttributes.distribution.url});
    //    //if (datasetWithSameLink) {                                 //
    //    //    return {                                               //
    //    //        postExists: true,                                  //
    //    //        _id: datasetWithSameLink._id                       //
    //    //    }                                                      //
    //    //}                                                          //
    //                                                                 //
    //    let user = Meteor.user();                                    //
    //    let dataset = _.extend(datasetAttributes, {                  //
    //        publisher: user._id,                                     //
    //        commentsCount: 0,                                        //
    //        upvoters: [],                                            //
    //        votes: 0                                                 //
    //    });                                                          //
    //                                                                 //
    //    let datasetId = Datasets.insert(dataset);                    //
    //                                                                 //
    //    return {                                                     //
    //        _id: datasetId                                           //
    //    };                                                           //
    //},                                                               //
                                                                       //
    upvote: function (entryId, category) {                             // 40
        check(this.userId, String);                                    // 41
        check(entryId, String);                                        // 42
        check(category, Mongo.Collection);                             // 43
        check(category.singularName, Match.OneOf('dataset', 'app'));   // 44
                                                                       //
        var affected = category.update({                               // 46
            _id: entryId,                                              // 47
            upvoters: { $ne: this.userId }                             // 48
        }, {                                                           //
            $addToSet: { upvoters: this.userId },                      // 50
            $inc: { votes: 1 }                                         // 51
        });                                                            //
                                                                       //
        if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");
    },                                                                 //
    downvote: function (entryId, category) {                           // 57
        check(this.userId, String);                                    // 58
        check(entryId, String);                                        // 59
        check(category, Mongo.Collection);                             // 60
        check(category.singularName, Match.OneOf('dataset', 'app'));   // 61
                                                                       //
        var affected = category.update({                               // 63
            _id: entryId,                                              // 64
            downvoters: { $ne: this.userId }                           // 65
        }, {                                                           //
            $addToSet: { downvoters: this.userId },                    // 67
            $inc: { downvotes: 1 }                                     // 68
        });                                                            //
                                                                       //
        if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=creative_work.js.map
