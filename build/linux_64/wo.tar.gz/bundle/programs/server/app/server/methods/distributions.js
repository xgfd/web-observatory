(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/distributions.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by xgfd on 02/01/2016.                                      //
 */                                                                    //
var connPool = {};                                                     // 4
                                                                       //
function augsTrans(url, username, pass) {                              // 6
                                                                       //
    if (arguments.length === 1) {                                      // 8
        if (!url.match(/^.*:\/\//)) {                                  // 9
            var distId = url,                                          // 10
                dist = Datasets.findOne({ 'distribution._id': distId }, { fields: { distribution: { $elemMatch: { _id: distId } } } }).distribution[0];
                                                                       //
            //console.log(dist);                                       //
                                                                       //
            if (dist) {                                                // 15
                url = dist.url;                                        // 16
                var _dist$profile = dist.profile;                      //
                username = _dist$profile.username;                     // 16
                pass = _dist$profile.pass;                             // 16
            } else {                                                   //
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not found');
            }                                                          //
        }                                                              //
    }                                                                  //
                                                                       //
    return { url: url, username: username, pass: pass };               // 23
}                                                                      //
                                                                       //
function connectorFactory(connect) {                                   // 26
    return function (url, username, pass) {                            // 27
        var originUrl = url;                                           // 28
                                                                       //
        var _augsTrans$apply = augsTrans.apply(null, arguments);       //
                                                                       //
        url = _augsTrans$apply.url;                                    // 30
        username = _augsTrans$apply.username;                          // 30
        pass = _augsTrans$apply.pass;                                  // 30
                                                                       //
        var _Async$runSync = Async.runSync(function (done) {           //
            connect(url, username, pass, done);                        // 33
        });                                                            //
                                                                       //
        var error = _Async$runSync.error;                              //
        var result = _Async$runSync.result;                            //
                                                                       //
        if (error) {                                                   // 36
            throw new Meteor.Error(error.name, error.message);         // 37
        } else {                                                       //
            connPool[originUrl] = result;                              // 39
            return true;                                               // 40
        }                                                              //
    };                                                                 //
}                                                                      //
                                                                       //
/*                                                                     //
 * @connector(distId) create an db connection and save it to dbPool    //
 * @queryExec(db, done, ...args) query execution function. result is passed to done(error, result)
 * */                                                                  //
function queryerFactory(connector, queryExec) {                        // 49
    return function (distId) {                                         // 50
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            args[_key - 1] = arguments[_key];                          // 50
        }                                                              //
                                                                       //
        var conn = connPool[distId];                                   // 51
                                                                       //
        if (!conn) {                                                   // 53
            connector(distId);                                         // 54
        }                                                              //
                                                                       //
        conn = connPool[distId];                                       // 57
                                                                       //
        if (!conn) {                                                   // 59
            throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');
        }                                                              //
                                                                       //
        var _Async$runSync2 = Async.runSync(function (done) {          //
            queryExec.apply(undefined, [conn, done].concat(args));     // 64
        });                                                            //
                                                                       //
        var error = _Async$runSync2.error;                             //
        var result = _Async$runSync2.result;                           //
                                                                       //
        if (error) {                                                   // 67
            throw new Meteor.Error(error.name, error.message);         // 68
        } else {                                                       //
            return result;                                             // 70
        }                                                              //
    };                                                                 //
}                                                                      //
                                                                       //
//TODO close connections using settimeout                              //
                                                                       //
/*MongoDB*/                                                            //
var mongoclient = Meteor.npmRequire("mongodb").MongoClient;            // 78
                                                                       //
/*                                                                     //
 call with one parameter @distId or three parameters @url @username @pass
 */                                                                    //
var mongodbConnect = connectorFactory(function (url, username, pass, done) {
    if (username) {                                                    // 84
        url = 'mongodb://' + username + ':' + pass + '@' + url.slice('mongodb://'.length);
    }                                                                  //
    mongoclient.connect(url, done);                                    // 87
});                                                                    //
                                                                       //
/* MySQL */                                                            //
var mysql = Meteor.npmRequire('mysql');                                // 91
                                                                       //
var mysqlConnect = connectorFactory(function (url, username, pass, done) {
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://      // 94
                                                                       //
    var options = {                                                    // 96
        connectionLimit: 20,                                           // 97
        host: url                                                      // 98
    };                                                                 //
                                                                       //
    if (username) {                                                    // 101
        options.user = username;                                       // 102
    }                                                                  //
                                                                       //
    if (pass) {                                                        // 105
        options.pass = pass;                                           // 106
    }                                                                  //
                                                                       //
    var pool = mysql.createPool(options);                              // 109
                                                                       //
    done(null, pool);                                                  // 111
});                                                                    //
                                                                       //
/*RabbitMQ*/                                                           //
var amqp = Meteor.npmRequire('amqplib/callback_api');                  // 115
var amqpConnect = connectorFactory(function (url, username, pass, done) {
    var parts = url.match(/(amqps?:\/\/)?([^\?]*)\??(\S*)/),           // 117
        query = parts[3],                                              //
        params = query.split(/[=,&]/),                                 //
        exchanges = params[params.indexOf('exchange') + 1].split(','); //value of query exchange can be a comma separate list
                                                                       //
    if (username) {                                                    // 122
        url = parts[1] + (username + ':' + pass + '@') + parts[2] + (query ? '?' + query : '');
    }                                                                  //
                                                                       //
    amqp.connect(url, function (error, conn) {                         // 126
        if (conn && !conn.exchanges) {                                 // 127
            conn.exchanges = exchanges;                                // 128
        }                                                              //
        done(error, conn);                                             // 130
    });                                                                //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 134
    //connect                                                          //
    mongodbConnect: mongodbConnect,                                    // 136
    mysqlConnect: mysqlConnect,                                        // 137
    amqpConnect: amqpConnect,                                          // 138
                                                                       //
    //query                                                            //
    mongodbQuery: queryerFactory(mongodbConnect, function (conn, done, collection) {
        var selector = arguments.length <= 3 || arguments[3] === undefined ? {} : arguments[3];
        var options = arguments.length <= 4 || arguments[4] === undefined ? {} : arguments[4];
                                                                       //
        conn.collection(collection, function (error, col) {            // 142
            if (error) {                                               // 143
                throw new Meteor.Error(error.name, error.message);     // 144
            }                                                          //
            var query = col.find(selector);                            // 146
                                                                       //
            for (var key in babelHelpers.sanitizeForInObject(options)) {
                if (options.hasOwnProperty(key)) {                     // 149
                    query = query[key](options[key]);                  // 150
                }                                                      //
            }                                                          //
            query.toArray(done);                                       // 153
        });                                                            //
    }),                                                                //
    //utils                                                            //
    mongodbCollectionNames: function (distId) {                        // 157
        var db = connPool[distId];                                     // 158
                                                                       //
        if (!db) {                                                     // 160
            mongodbConnect(distId);                                    // 161
        }                                                              //
                                                                       //
        db = connPool[distId];                                         // 164
                                                                       //
        if (!db) {                                                     // 166
            throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');
        }                                                              //
                                                                       //
        var _Async$runSync3 = Async.runSync(function (done) {          //
            db.listCollections().toArray(done);                        // 171
        });                                                            //
                                                                       //
        var error = _Async$runSync3.error;                             //
        var result = _Async$runSync3.result;                           //
                                                                       //
        if (error) {                                                   // 174
            throw new Meteor.Error(error.name, error.message);         // 175
        } else {                                                       //
            result = result.filter(function (x) {                      // 177
                return x.name !== 'system.indexes';                    // 178
            });                                                        //
            //console.log(result);                                     //
            return result;                                             // 181
        }                                                              //
    },                                                                 //
    mysqlQuery: queryerFactory(mysqlConnect, function (conn, done, query) {
        conn.query(query, done); // db.query returns a third argument @fields which is discarded
    }),                                                                //
    sparqlQuery: queryerFactory(connectorFactory(function (url, username, pass, done) {
        done(null, url);                                               // 188
    }), function (url, done, query) {                                  //
        HTTP.get(url, {                                                // 190
            params: { query: query }, timeout: 30000, headers: {       // 191
                'Content-Type': 'application/x-www-form-urlencoded',   // 192
                'Accept': 'application/sparql-results+json'            // 193
            }                                                          //
        }, function (error, result) {                                  //
            if (typeof result === 'object' && result.content) {        // 196
                try {                                                  // 197
                    result = result.content;                           // 198
                } catch (e) {                                          //
                    console.log(e);                                    // 200
                }                                                      //
            }                                                          //
            done(error, result);                                       // 203
        });                                                            //
    }),                                                                //
    amqpQuery: queryerFactory(amqpConnect, function (conn, done, ex, sId) {
        var exchanges = conn.exchanges;                                // 207
        if (_.contains(exchanges, ex)) {                               // 208
            conn.createChannel(function (err, ch) {                    // 209
                var socket = Streamy.sockets(sId);                     // 210
                //keep the channel associate with a client (socket) to close it later
                if (channels[sId]) {                                   // 212
                    closeCh(channels[sId], sId);                       // 213
                }                                                      //
                channels[sId] = ch;                                    // 215
                ch.assertExchange(ex, 'fanout', { durable: false });   // 216
                ch.assertQueue('', { exclusive: true }, function (err, q) {
                    ch.on('close', function () {                       // 218
                        console.log(sId + ' channel closed');          // 219
                        Streamy.emit(q.queue, { content: sId + ' channel closed' }, socket);
                    });                                                //
                    done(err, q.queue);                                // 222
                    Streamy.emit(q.queue, { content: " [*] Waiting for messages" }, socket);
                    ch.bindQueue(q.queue, ex, '');                     // 224
                    ch.consume(q.queue, function (msg) {               // 225
                        //console.log(" [x] %s", msg.content.toString());
                        var content = msg.content.toString();          // 227
                        Streamy.emit(q.queue, { content: content }, socket);
                    }, { noAck: true });                               //
                });                                                    //
            });                                                        //
        } else {                                                       //
            return done(new Error('Unrecognised exchange'));           // 233
        }                                                              //
    }),                                                                //
    amqpCollectionNames: function (distId) {                           // 236
        var conn = connPool[distId];                                   // 237
                                                                       //
        if (!conn) {                                                   // 239
            amqpConnect(distId);                                       // 240
        }                                                              //
                                                                       //
        conn = connPool[distId];                                       // 243
                                                                       //
        if (!conn) {                                                   // 245
            throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');
        }                                                              //
                                                                       //
        return conn.exchanges;                                         // 249
    }                                                                  //
});                                                                    //
                                                                       //
var channels = {}; //socketId:channel, each socket only allows for one channels
function closeCh(ch, sId) {                                            // 254
    if (ch) {                                                          // 255
        try {                                                          // 256
            ch.close();                                                // 257
        } catch (e) {                                                  //
            console.log(e.stackAtStateChange);                         // 260
        } finally {                                                    //
            delete channels[sId];                                      // 263
        }                                                              //
    }                                                                  //
}                                                                      //
/**                                                                    //
 * Upon disconnect, clear the client database                          //
 */                                                                    //
Streamy.onDisconnect(function (socket) {                               // 270
    var sId = Streamy.id(socket),                                      // 271
        ch = channels[sId];                                            //
                                                                       //
    closeCh(ch, sId);                                                  // 274
    Streamy.broadcast('__leave__', {                                   // 275
        'sid': Streamy.id(socket)                                      // 276
    });                                                                //
});                                                                    //
                                                                       //
Streamy.on('amqp_end', function (socket) {                             // 280
    var sId = Streamy.id(socket),                                      // 281
        ch = channels[sId];                                            //
                                                                       //
    closeCh(ch, sId);                                                  // 284
    Streamy.broadcast('__leave__', {                                   // 285
        'sid': Streamy.id(socket)                                      // 286
    });                                                                //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=distributions.js.map
