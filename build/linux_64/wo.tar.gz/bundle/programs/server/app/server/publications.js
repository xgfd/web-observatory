(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/*collection publication*/                                             //
publish({                                                              // 2
    datasets: Datasets,                                                // 3
    apps: Apps,                                                        // 4
    groups: Groups,                                                    // 5
    licenses: Licenses,                                                // 6
    userNames: Meteor.users                                            // 7
}, Meteor.publish, function (collection) {                             //
    return function () {                                               // 9
        var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
        var selector = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
                                                                       //
        //check(options, {                                             //
        //    fields: Match.Optional(Object),                          //
        //    skip: Match.Optional(Object),                            //
        //    sort: Match.Optional(Object),                            //
        //    limit: Match.Optional(Number)                            //
        //});                                                          //
        if (!selector) {                                               // 16
            selector = {};                                             // 17
        }                                                              //
                                                                       //
        if (!options) {                                                // 20
            options = {};                                              // 21
        }                                                              //
                                                                       //
        check(selector, Object);                                       // 24
                                                                       //
        switch (collection) {                                          // 26
            case Meteor.users:                                         // 27
                options.fields = { username: 1 };                      // 28
                break;                                                 // 29
                                                                       //
            case Datasets:                                             // 29
                var userId = this.userId;                              // 32
                extendOr(selector, viewsDocumentQuery(userId));        // 33
                options.fields = {                                     // 34
                    //'distribution.url': 0,                           //
                    'distribution.file': 0,                            // 36
                    'distribution.profile.username': 0,                // 37
                    'distribution.profile.pass': 0                     // 38
                };                                                     //
                break;                                                 // 40
                                                                       //
            case Apps:                                                 // 40
                userId = this.userId;                                  // 43
                extendOr(selector, viewsDocumentQuery(userId));        // 44
                break;                                                 // 45
        }                                                              // 45
                                                                       //
        return collection.find(selector, options);                     // 48
    };                                                                 //
});                                                                    //
                                                                       //
publish({ singleDataset: Datasets, singleApp: Apps, singleGroup: Groups }, Meteor.publish, function (collection) {
    return function (id) {                                             // 53
        var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
                                                                       //
        check(id, String);                                             // 54
                                                                       //
        var selector = { _id: id },                                    // 56
            userId = this.userId;                                      //
                                                                       //
        extendOr(selector, viewsDocumentQuery(userId));                // 59
        options.fields = {                                             // 60
            //'distribution.url': 0,                                   //
            'distribution.file': 0,                                    // 62
            'distribution.profile.username': 0,                        // 63
            'distribution.profile.pass': 0                             // 64
        };                                                             //
                                                                       //
        return collection.find(selector, options);                     // 67
    };                                                                 //
});                                                                    //
                                                                       //
Meteor.publish('comments', function (entryId) {                        // 71
    check(entryId, String);                                            // 72
    return Comments.find({ entryId: entryId });                        // 73
});                                                                    //
                                                                       //
Meteor.publish('notifications', function () {                          // 76
    return Notifications.find({ userId: this.userId, read: false });   // 77
});                                                                    //
                                                                       //
Meteor.publish('images', function () {                                 // 80
    return Images.find();                                              // 81
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
