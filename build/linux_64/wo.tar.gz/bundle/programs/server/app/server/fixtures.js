(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fixtures.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.settings["public"].environment === 'dev' && !Meteor.settings["public"].migrate) {
    /* testing cases                                                   //
     *               ds1 (all)     ds2 (none)     ds3 (group)          //
     * admin           own             y            own                //
     * individual      y               own          n                  //
     * member          y               n            y                  //
     * group           y               n            y                  //
     * */                                                              //
                                                                       //
    function addAdmin(name) {                                          // 10
                                                                       //
        var xgfdId = Accounts.createUser({                             // 12
            profile: {                                                 // 13
                name: name                                             // 14
            },                                                         //
            username: name,                                            // 16
            email: name + "@example.com",                              // 17
            password: "123456"                                         // 18
        });                                                            //
                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);             // 21
        Roles.addUserToRoles(xgfdId, ["admin"]);                       // 22
                                                                       //
        return xgfdId;                                                 // 24
    }                                                                  //
                                                                       //
    function addIndividual(name) {                                     // 27
        return Accounts.createUser({                                   // 28
            profile: {                                                 // 29
                name: name                                             // 30
            },                                                         //
            username: name,                                            // 32
            email: name + "@example.com",                              // 33
            password: "123456"                                         // 34
        });                                                            //
    }                                                                  //
                                                                       //
    function addGroup(name) {                                          // 38
        var xgfdId = Accounts.createUser({                             // 39
            profile: {                                                 // 40
                name: name,                                            // 41
                isgroup: true,                                         // 42
                description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
                url: "https://www.google.co.uk"                        // 44
            },                                                         //
            username: name,                                            // 46
            email: name + "@example.com",                              // 47
            password: "123456"                                         // 48
        });                                                            //
                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);             // 51
        Roles.addUserToRoles(xgfdId, ["group"]);                       // 52
                                                                       //
        return xgfdId;                                                 // 54
    }                                                                  //
                                                                       //
    var xgfdId = undefined,                                            // 57
        individualId = undefined,                                      //
        groupId = undefined,                                           //
        memberId = undefined;                                          //
    if (Meteor.users.find().count() === 0) {                           // 58
        xgfdId = addAdmin('xgfd');                                     // 59
        individualId = addIndividual('individual');                    // 60
        groupId = addGroup('group');                                   // 61
        memberId = addIndividual('member');                            // 62
        var tmp = Meteor.call('addToGroup', memberId, Groups.findOne({ publisher: groupId })._id);
    }                                                                  //
    // Fixture data                                                    //
    var telescopeId = undefined;                                       // 66
    if (Datasets.find().count() === 0) {                               // 67
        var now = new Date().getTime();                                // 68
                                                                       //
        telescopeId = Datasets.insert({                                // 70
            name: 'Introducing Telescope',                             // 71
            publisher: xgfdId,                                         // 72
            distribution: [{                                           // 73
                url: 'mongodb://localhost:3001/meteor',                // 74
                fileFormat: "MongoDB",                                 // 75
                online: true                                           // 76
            }, {                                                       //
                url: 'amqp://wsi-h1.soton.ac.uk?exchange=logs',        // 78
                fileFormat: "AMQP",                                    // 79
                online: true                                           // 80
            }],                                                        //
            license: "MIT",                                            // 82
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 2,                                          // 84
            aclContent: false,                                         // 85
            online: true,                                              // 86
            upvoters: [], votes: 0                                     // 87
        });                                                            //
                                                                       //
        Comments.insert({                                              // 90
            entryId: telescopeId,                                      // 91
            publisher: individualId,                                   // 92
            submitted: new Date(now - 5 * 3600 * 1000),                // 93
            body: 'Interesting project Sacha, can I get involved?'     // 94
        });                                                            //
                                                                       //
        Comments.insert({                                              // 97
            entryId: telescopeId,                                      // 98
            publisher: xgfdId,                                         // 99
            submitted: new Date(now - 3 * 3600 * 1000),                // 100
            body: "<p><span style=\"font-family: 'Comic Sans MS';\"><span style=\"font-size: 18px; background-color: rgb(255, 0, 0);\">You</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 156, 0);\">sure</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 255, 0);\">can</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(0, 255, 0);\">Tom</span><span style=\"font-size: 18px; background-color: rgb(0, 0, 255);\">!!!</span></span></p>"
        });                                                            //
                                                                       //
        Datasets.insert({                                              // 104
            name: 'The Meteor Book',                                   // 105
            publisher: individualId,                                   // 106
            distribution: [{                                           // 107
                url: 'http://themeteorbook.com',                       // 108
                fileFormat: "MySQL",                                   // 109
                online: false                                          // 110
            }, {                                                       //
                url: 'http://dbpedia.org/sparql',                      // 112
                fileFormat: "SPARQL",                                  // 113
                online: true                                           // 114
            }],                                                        //
            license: "MIT",                                            // 116
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi pharetra augue eget hendrerit bibendum. Vivamus quis laoreet magna. Quisque eu mi sit amet lorem vestibulum rhoncus. Donec lacus est, sodales convallis urna nec, condimentum accumsan ligula. Nullam maximus a sem ac laoreet. In hac habitasse platea dictumst. Pellentesque porttitor ex orci, sed suscipit ante pretium eget. Nam vestibulum metus a libero ultricies molestie sed vel est. Maecenas porta tempus purus, sed pharetra nibh sodales vitae. Nullam in erat tristique, posuere enim laoreet, suscipit erat. Sed quis efficitur enim. 2",
            commentsCount: 0,                                          // 118
            online: false,                                             // 119
            aclMeta: false,                                            // 120
            upvoters: [], votes: 0                                     // 121
        });                                                            //
                                                                       //
        Datasets.insert({                                              // 124
            name: 'Group visible dataset',                             // 125
            publisher: xgfdId,                                         // 126
            distribution: [{                                           // 127
                url: 'http://sachagreif.com/introducing-telescope/',   // 128
                fileFormat: "HTML",                                    // 129
                online: true                                           // 130
            }],                                                        //
            license: "MIT",                                            // 132
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 0,                                          // 134
            aclMeta: false,                                            // 135
            aclContent: false,                                         // 136
            metaWhiteList: [groupId],                                  // 137
            contentWhiteList: [groupId],                               // 138
            online: true,                                              // 139
            upvoters: [], votes: 0                                     // 140
        });                                                            //
                                                                       //
        for (var i = 0; i < 50; i++) {                                 // 143
            Apps.insert({                                              // 144
                name: 'Test app #' + i,                                // 145
                url: 'http://sachagreif.com/introducing-telescope/#' + i,
                publisher: groupId,                                    // 147
                license: "MIT",                                        // 148
                aclContent: !!(i % 2),                                 // 149
                description: "Etiam porttitor purus et mollis malesuada. Nulla tempor orci id ex tincidunt consectetur. Praesent et dignissim lectus, in posuere ante. Curabitur nunc dolor, interdum a ornare eget, laoreet eu metus. Ut tempor lacinia eros nec finibus. Maecenas quis felis non mi euismod consectetur quis at leo. Nullam porta tempus ullamcorper. Phasellus et nibh feugiat, iaculis massa eget, blandit quam. Aliquam dolor justo, feugiat et sem ut, fermentum elementum arcu. Aliquam quis tincidunt tortor. Suspendisse potenti. Duis congue sapien ac purus iaculis pharetra. Donec hendrerit lacus leo, non ultricies purus accumsan nec. Nulla vel suscipit quam. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
                commentsCount: 0,                                      // 151
                upvoters: [], votes: 0                                 // 152
            });                                                        //
        }                                                              //
    }                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fixtures.js.map
