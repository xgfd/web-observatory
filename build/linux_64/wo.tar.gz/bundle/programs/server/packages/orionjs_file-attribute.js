(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:filesystem'].orion;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_file-attribute/attribute.js                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
orion.attributes.registerAttribute('file', {                         // 1
  template: 'orionAttributesFileUpload',                             // 2
  previewTemplate: 'orionAttributesFileUploadColumn',                // 3
  getSchema: function (options) {                                    // 4
    var subSchema = new SimpleSchema({                               // 5
      url: {                                                         // 6
        type: String                                                 // 7
      },                                                             //
      fileId: {                                                      // 9
        type: String                                                 // 10
      }                                                              //
    });                                                              //
    return {                                                         // 13
      type: subSchema                                                // 14
    };                                                               //
  },                                                                 //
  valueOut: function () {                                            // 17
    return Session.get('file' + this.attr('data-schema-key'));       // 18
  }                                                                  //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:file-attribute'] = {};

})();

//# sourceMappingURL=orionjs_file-attribute.js.map
