(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Tabular, tablesByName;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/nicolaslopezj_tabular-materialize/packages/nicolaslopezj_tabular-materialize.js        //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
(function () {                                                                                     // 1
                                                                                                   // 2
//////////////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                          //     // 4
// packages/nicolaslopezj:tabular-materialize/common.js                                     //     // 5
//                                                                                          //     // 6
//////////////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                            //     // 8
/* global Tabular:true, tablesByName:true, Mongo, _, Meteor */                              // 1   // 9
                                                                                            // 2   // 10
Tabular = {}; //exported                                                                    // 3   // 11
                                                                                            // 4   // 12
tablesByName = {};                                                                          // 5   // 13
                                                                                            // 6   // 14
Tabular.Table = function (options) {                                                        // 7   // 15
  var self = this;                                                                          // 8   // 16
                                                                                            // 9   // 17
  if (!options) {                                                                           // 10  // 18
    throw new Error('Tabular.Table options argument is required');                          // 11  // 19
  }                                                                                         // 12  // 20
                                                                                            // 13  // 21
  if (!options.name) {                                                                      // 14  // 22
    throw new Error('Tabular.Table options must specify name');                             // 15  // 23
  }                                                                                         // 16  // 24
  self.name = options.name;                                                                 // 17  // 25
                                                                                            // 18  // 26
  if (!(options.collection instanceof Mongo.Collection)) {                                  // 19  // 27
    throw new Error('Tabular.Table options must specify collection');                       // 20  // 28
  }                                                                                         // 21  // 29
  self.collection = options.collection;                                                     // 22  // 30
                                                                                            // 23  // 31
  self.pub = options.pub || 'tabular_genericPub';                                           // 24  // 32
                                                                                            // 25  // 33
  // By default we use core `Meteor.subscribe`, but you can pass                            // 26  // 34
  // a subscription manager like `sub: new SubsManager({cacheLimit: 20, expireIn: 3})`      // 27  // 35
  self.sub = options.sub || Meteor;                                                         // 28  // 36
                                                                                            // 29  // 37
  self.onUnload = options.onUnload;                                                         // 30  // 38
  self.allow = options.allow;                                                               // 31  // 39
  self.allowFields = options.allowFields;                                                   // 32  // 40
  self.changeSelector = options.changeSelector;                                             // 33  // 41
                                                                                            // 34  // 42
  if (_.isArray(options.extraFields)) {                                                     // 35  // 43
    var fields = {};                                                                        // 36  // 44
    _.each(options.extraFields, function (fieldName) {                                      // 37  // 45
      fields[fieldName] = 1;                                                                // 38  // 46
    });                                                                                     // 39  // 47
    self.extraFields = fields;                                                              // 40  // 48
  }                                                                                         // 41  // 49
                                                                                            // 42  // 50
  self.selector = options.selector;                                                         // 43  // 51
                                                                                            // 44  // 52
  if (!options.columns) {                                                                   // 45  // 53
    throw new Error('Tabular.Table options must specify columns');                          // 46  // 54
  }                                                                                         // 47  // 55
                                                                                            // 48  // 56
  self.options = _.omit(options, 'collection', 'pub', 'sub', 'onUnload', 'allow', 'allowFields', 'extraFields', 'name', 'selector');
                                                                                            // 50  // 58
  tablesByName[self.name] = self;                                                           // 51  // 59
};                                                                                          // 52  // 60
                                                                                            // 53  // 61
//////////////////////////////////////////////////////////////////////////////////////////////     // 62
                                                                                                   // 63
}).call(this);                                                                                     // 64
                                                                                                   // 65
                                                                                                   // 66
                                                                                                   // 67
                                                                                                   // 68
                                                                                                   // 69
                                                                                                   // 70
(function () {                                                                                     // 71
                                                                                                   // 72
//////////////////////////////////////////////////////////////////////////////////////////////     // 73
//                                                                                          //     // 74
// packages/nicolaslopezj:tabular-materialize/server/tabular.js                             //     // 75
//                                                                                          //     // 76
//////////////////////////////////////////////////////////////////////////////////////////////     // 77
                                                                                            //     // 78
/* global check, Match, Meteor, tablesByName, _ */                                          // 1   // 79
                                                                                            // 2   // 80
/*                                                                                          // 3   // 81
 * These are the two publications used by TabularTable.                                     // 4   // 82
 *                                                                                          // 5   // 83
 * The genericPub one can be overridden by supplying a `pub`                                // 6   // 84
 * property with a different publication name. This publication                             // 7   // 85
 * is given only the list of ids and requested fields. You may                              // 8   // 86
 * want to override it if you need to publish documents from                                // 9   // 87
 * related collections along with the table collection documents.                           // 10  // 88
 *                                                                                          // 11  // 89
 * The getInfo one runs first and handles all the complex logic                             // 12  // 90
 * required by this package, so that you don't have to duplicate                            // 13  // 91
 * this logic when overriding the genericPub function.                                      // 14  // 92
 *                                                                                          // 15  // 93
 * Having two publications also allows fine-grained control of                              // 16  // 94
 * reactivity on the client.                                                                // 17  // 95
 */                                                                                         // 18  // 96
                                                                                            // 19  // 97
Meteor.publish("tabular_genericPub", function (tableName, ids, fields) {                    // 20  // 98
  var self = this;                                                                          // 21  // 99
                                                                                            // 22  // 100
  check(tableName, String);                                                                 // 23  // 101
  check(ids, Array);                                                                        // 24  // 102
  check(fields, Match.Optional(Object));                                                    // 25  // 103
                                                                                            // 26  // 104
  var table = tablesByName[tableName];                                                      // 27  // 105
  if (!table) {                                                                             // 28  // 106
    // We throw an error in the other pub, so no need to throw one here                     // 29  // 107
    self.ready();                                                                           // 30  // 108
    return;                                                                                 // 31  // 109
  }                                                                                         // 32  // 110
                                                                                            // 33  // 111
  // Extend fields list with extra fields from the table definition                         // 34  // 112
  if (table.extraFields) {                                                                  // 35  // 113
    _.extend(fields, table.extraFields);                                                    // 36  // 114
  }                                                                                         // 37  // 115
                                                                                            // 38  // 116
  // Check security. We call this in both publications.                                     // 39  // 117
  if (typeof table.allow === 'function' && !table.allow(self.userId, fields)) {             // 40  // 118
    self.ready();                                                                           // 41  // 119
    return;                                                                                 // 42  // 120
  }                                                                                         // 43  // 121
                                                                                            // 44  // 122
  // Check security for fields. We call this only in this publication                       // 45  // 123
  if (typeof table.allowFields === 'function' && !table.allowFields(self.userId, fields)) { // 46  // 124
    self.ready();                                                                           // 47  // 125
    return;                                                                                 // 48  // 126
  }                                                                                         // 49  // 127
                                                                                            // 50  // 128
  return table.collection.find({_id: {$in: ids}}, {fields: fields});                        // 51  // 129
});                                                                                         // 52  // 130
                                                                                            // 53  // 131
Meteor.publish("tabular_getInfo", function(tableName, selector, sort, skip, limit) {        // 54  // 132
  var self = this;                                                                          // 55  // 133
                                                                                            // 56  // 134
  check(tableName, String);                                                                 // 57  // 135
  check(selector, Match.Optional(Match.OneOf(Object, null)));                               // 58  // 136
  check(sort, Match.Optional(Match.OneOf(Array, null)));                                    // 59  // 137
  check(skip, Number);                                                                      // 60  // 138
  check(limit, Number);                                                                     // 61  // 139
                                                                                            // 62  // 140
  var table = tablesByName[tableName];                                                      // 63  // 141
  if (!table) {                                                                             // 64  // 142
    throw new Error('No TabularTable defined with the name "' + tableName + '". Make sure you are defining your TabularTable in common code.');
  }                                                                                         // 66  // 144
                                                                                            // 67  // 145
  // Verify that limit is not 0, because that will actually                                 // 68  // 146
  // publish all document _ids.                                                             // 69  // 147
  if (limit === 0) {                                                                        // 70  // 148
    limit = 1;                                                                              // 71  // 149
  }                                                                                         // 72  // 150
                                                                                            // 73  // 151
  // Check security. We call this in both publications.                                     // 74  // 152
  // Even though we're only publishing _ids and counts                                      // 75  // 153
  // from this function, with sensitive data, there is                                      // 76  // 154
  // a chance someone could do a query and learn something                                  // 77  // 155
  // just based on whether a result is found or not.                                        // 78  // 156
  if (typeof table.allow === 'function' && !table.allow(self.userId)) {                     // 79  // 157
    self.ready();                                                                           // 80  // 158
    return;                                                                                 // 81  // 159
  }                                                                                         // 82  // 160
                                                                                            // 83  // 161
  selector = selector || {};                                                                // 84  // 162
                                                                                            // 85  // 163
  // Allow the user to modify the selector before we use it                                 // 86  // 164
  if (typeof table.changeSelector === 'function') {                                         // 87  // 165
    selector = table.changeSelector(selector, self.userId);                                 // 88  // 166
  }                                                                                         // 89  // 167
                                                                                            // 90  // 168
  // Apply the server side selector specified in the tabular                                // 91  // 169
  // table constructor. Both must be met, so we join                                        // 92  // 170
  // them using $and, allowing both selectors to have                                       // 93  // 171
  // the same keys.                                                                         // 94  // 172
  if (typeof table.selector === 'function') {                                               // 95  // 173
    var tableSelector = table.selector(self.userId);                                        // 96  // 174
    if (_.isEmpty(selector)) {                                                              // 97  // 175
      selector = tableSelector;                                                             // 98  // 176
    } else {                                                                                // 99  // 177
      selector = {$and: [tableSelector, selector]};                                         // 100
    }                                                                                       // 101
  }                                                                                         // 102
                                                                                            // 103
  var findOptions = {                                                                       // 104
    skip: skip,                                                                             // 105
    limit: limit,                                                                           // 106
    fields: {_id: 1}                                                                        // 107
  };                                                                                        // 108
                                                                                            // 109
  // `sort` may be `null`                                                                   // 110
  if (_.isArray(sort)) {                                                                    // 111
    findOptions.sort = sort;                                                                // 112
  }                                                                                         // 113
                                                                                            // 114
  var filteredCursor = table.collection.find(selector, findOptions);                        // 115
                                                                                            // 116
  var filteredRecordIds = filteredCursor.map(function (doc) {                               // 117
    return doc._id;                                                                         // 118
  });                                                                                       // 119
                                                                                            // 120
  var countCursor = table.collection.find(selector, {fields: {_id: 1}});                    // 121
                                                                                            // 122
  var recordReady = false;                                                                  // 123
  function updateRecords() {                                                                // 124
    var currentCount = countCursor.count();                                                 // 125
                                                                                            // 126
    var record = {                                                                          // 127
      ids: filteredRecordIds,                                                               // 128
      // count() will give us the updated total count                                       // 129
      // every time. It does not take the find options                                      // 130
      // limit into account.                                                                // 131
      recordsTotal: currentCount,                                                           // 132
      recordsFiltered: currentCount                                                         // 133
    };                                                                                      // 134
                                                                                            // 135
    if (recordReady) {                                                                      // 136
      //console.log("changed", tableName, record);                                          // 137
      self.changed('tabular_records', tableName, record);                                   // 138
    } else {                                                                                // 139
      //console.log("added", tableName, record);                                            // 140
      self.added("tabular_records", tableName, record);                                     // 141
      recordReady = true;                                                                   // 142
    }                                                                                       // 143
  }                                                                                         // 144
                                                                                            // 145
  // Handle docs being added or removed from the result set.                                // 146
  var initializing1 = true;                                                                 // 147
  var handle1 = filteredCursor.observeChanges({                                             // 148
    added: function (id) {                                                                  // 149
      if (initializing1) {                                                                  // 150
        return;                                                                             // 151
      }                                                                                     // 152
                                                                                            // 153
      //console.log("ADDED");                                                               // 154
      filteredRecordIds.push(id);                                                           // 155
      updateRecords();                                                                      // 156
    },                                                                                      // 157
    removed: function (id) {                                                                // 158
      //console.log("REMOVED");                                                             // 159
      filteredRecordIds = _.without(filteredRecordIds, id);                                 // 160
      updateRecords();                                                                      // 161
    }                                                                                       // 162
  });                                                                                       // 163
  initializing1 = false;                                                                    // 164
                                                                                            // 165
  // Handle docs being added or removed from the non-limited set.                           // 166
  // This allows us to get total count available.                                           // 167
  var initializing2 = true;                                                                 // 168
  var handle2 = countCursor.observeChanges({                                                // 169
    added: function () {                                                                    // 170
      if (initializing2) {                                                                  // 171
        return;                                                                             // 172
      }                                                                                     // 173
      updateRecords();                                                                      // 174
    },                                                                                      // 175
    removed: function () {                                                                  // 176
      updateRecords();                                                                      // 177
    }                                                                                       // 178
  });                                                                                       // 179
  initializing2 = false;                                                                    // 180
                                                                                            // 181
  updateRecords();                                                                          // 182
  self.ready();                                                                             // 183
                                                                                            // 184
  // Stop observing the cursors when client unsubs.                                         // 185
  // Stopping a subscription automatically takes                                            // 186
  // care of sending the client any removed messages.                                       // 187
  self.onStop(function () {                                                                 // 188
    handle1.stop();                                                                         // 189
    handle2.stop();                                                                         // 190
  });                                                                                       // 191
});                                                                                         // 192
                                                                                            // 193
//////////////////////////////////////////////////////////////////////////////////////////////     // 272
                                                                                                   // 273
}).call(this);                                                                                     // 274
                                                                                                   // 275
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:tabular-materialize'] = {
  Tabular: Tabular
};

})();

//# sourceMappingURL=nicolaslopezj_tabular-materialize.js.map
