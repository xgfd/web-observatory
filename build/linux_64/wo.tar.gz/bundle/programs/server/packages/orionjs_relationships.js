(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/attribute.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var getSchema = function (options, hasMany) {                                                                        // 1
  check(options, Match.ObjectIncluding({                                                                             // 2
    titleField: Match.OneOf(String, Array),                                                                          // 3
    publicationName: String,                                                                                         // 4
    customPublication: Match.Optional(Boolean),                                                                      // 5
    pluralName: Match.Optional(Match.OneOf(String, Function)),                                                       // 6
    singularName: Match.Optional(Match.OneOf(String, Function)),                                                     // 7
    collection: Mongo.Collection,                                                                                    // 8
    filter: Match.Optional(Function),                                                                                // 9
    createFilter: Match.Optional(Function),                                                                          // 10
    create: Match.Optional(Function),                                                                                // 11
    additionalFields: Match.Optional(Array),                                                                         // 12
    sortFields: Match.Optional(Match.OneOf(Array, Object)),                                                          // 13
    validateOnClient: Match.Optional(Boolean),                                                                       // 14
    validateOnServer: Match.Optional(Boolean),                                                                       // 15
    dontValidate: Match.Optional(Boolean),                                                                           // 16
    render: Match.Optional({                                                                                         // 17
      item: Function,                                                                                                // 18
      option: Function                                                                                               // 19
    })                                                                                                               //
  }));                                                                                                               //
                                                                                                                     //
  if (!_.has(options, 'validateOnClient')) {                                                                         // 23
    options.validateOnClient = true;                                                                                 // 24
  }                                                                                                                  //
                                                                                                                     //
  if (!_.has(options, 'validateOnServer')) {                                                                         // 27
    options.validateOnServer = true;                                                                                 // 28
  }                                                                                                                  //
                                                                                                                     //
  if (!options.filter) {                                                                                             // 31
    options.filter = function (userId) {                                                                             // 32
      return {};                                                                                                     // 33
    };                                                                                                               //
  }                                                                                                                  //
                                                                                                                     //
  if (!options.create) {                                                                                             // 37
    options.create = false;                                                                                          // 38
  }                                                                                                                  //
                                                                                                                     //
  if (_.isArray(options.titleField) && options.titleField.length === 1) {                                            // 41
    options.titleField = options.titleField[0];                                                                      // 42
  }                                                                                                                  //
                                                                                                                     //
  function render_item_default(item, escape) {                                                                       // 45
    var fieldContent = "";                                                                                           // 46
    if (_.isArray(options.titleField)) {                                                                             // 47
      _.each(options.titleField, function (field, index) {                                                           // 48
        fieldContent += (index > 0 ? " | " : "") + escape(item[field]);                                              // 48
      });                                                                                                            //
    } else {                                                                                                         //
      fieldContent = escape(item[options.titleField]);                                                               // 51
    }                                                                                                                //
    return '<div>' + fieldContent + '</div>';                                                                        // 53
  }                                                                                                                  //
                                                                                                                     //
  if (!options.render) {                                                                                             // 56
    options.render = {                                                                                               // 57
      item: render_item_default,                                                                                     // 58
      option: render_item_default                                                                                    // 59
    };                                                                                                               //
  }                                                                                                                  //
                                                                                                                     //
  if (!options.additionalFields) {                                                                                   // 63
    options.additionalFields = [];                                                                                   // 64
  }                                                                                                                  //
                                                                                                                     //
  if (!options.pluralName) {                                                                                         // 67
    options.pluralName = i18n('collections.common.defaultPluralName');                                               // 68
  }                                                                                                                  //
                                                                                                                     //
  if (!options.singularName) {                                                                                       // 71
    options.singularName = i18n('collections.common.defaultSingularName');                                           // 72
  }                                                                                                                  //
                                                                                                                     //
  options.fields = _.union(options.additionalFields, options.titleField);                                            // 75
                                                                                                                     //
  if (Meteor.isServer) {                                                                                             // 77
    if (!options.customPublication) {                                                                                // 78
      Meteor.publish(options.publicationName, function () {                                                          // 79
        var pubFields = {};                                                                                          // 80
        for (var i = 0; i < options.fields.length; i++) {                                                            // 81
          pubFields[options.fields[i]] = 1;                                                                          // 82
        }                                                                                                            //
        return options.collection.find(options.filter(this.userId), { fields: pubFields });                          // 84
      }, { is_auto: true });                                                                                         //
    }                                                                                                                //
    if (!hasMany) {                                                                                                  // 87
      Meteor.publish(options.publicationName + '_row', function (id) {                                               // 88
        var pubFields = {};                                                                                          // 89
        for (var i = 0; i < options.fields.length; i++) {                                                            // 90
          pubFields[options.fields[i]] = 1;                                                                          // 91
        }                                                                                                            //
        var filter = options.filter(this.userId);                                                                    // 93
        filter._id = id;                                                                                             // 94
        return options.collection.find(filter, { fields: pubFields });                                               // 95
      }, { is_auto: true });                                                                                         //
    }                                                                                                                //
  }                                                                                                                  //
                                                                                                                     //
  if (options.dontValidate && hasMany) {                                                                             // 100
    return {                                                                                                         // 101
      type: [String],                                                                                                // 102
      orion: options                                                                                                 // 103
    };                                                                                                               //
  } else if (options.dontValidate && !hasMany) {                                                                     //
    return {                                                                                                         // 106
      type: String,                                                                                                  // 107
      orion: options                                                                                                 // 108
    };                                                                                                               //
  } else if (hasMany) {                                                                                              //
    return {                                                                                                         // 111
      type: [String],                                                                                                // 112
      orion: options,                                                                                                // 113
      custom: function () {                                                                                          // 114
        if (Meteor.isClient && !options.validateOnClient) {                                                          // 115
          return;                                                                                                    // 116
        }                                                                                                            //
        if (Meteor.isServer && !options.validateOnServer) {                                                          // 118
          return;                                                                                                    // 119
        }                                                                                                            //
        if (this.isSet && _.isArray(this.value) && this.value) {                                                     // 121
          var count = options.collection.find({ $and: [{ _id: { $in: this.value } }, options.filter(this.userId)] }).count();
          if (count != this.value.length) {                                                                          // 123
            return 'notAllowed';                                                                                     // 124
          }                                                                                                          //
        }                                                                                                            //
      }                                                                                                              //
    };                                                                                                               //
  } else {                                                                                                           //
    return {                                                                                                         // 130
      type: String,                                                                                                  // 131
      orion: options,                                                                                                // 132
      custom: function () {                                                                                          // 133
        if (Meteor.isClient && !options.validateOnClient) {                                                          // 134
          return;                                                                                                    // 135
        }                                                                                                            //
        if (Meteor.isServer && !options.validateOnServer) {                                                          // 137
          return;                                                                                                    // 138
        }                                                                                                            //
        if (this.isSet && _.isString(this.value) && this.value) {                                                    // 140
          var count = options.collection.find({ $and: [{ _id: this.value }, options.filter(this.userId)] }).count();
          if (count != 1) {                                                                                          // 142
            return 'notAllowed';                                                                                     // 143
          }                                                                                                          //
        }                                                                                                            //
      }                                                                                                              //
    };                                                                                                               //
  }                                                                                                                  //
};                                                                                                                   //
                                                                                                                     //
orion.attributes.registerAttribute('hasMany', {                                                                      // 151
  template: 'orionAttributesHasMany',                                                                                // 152
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 153
  getSchema: function (options) {                                                                                    // 154
    return getSchema(options, true);                                                                                 // 155
  },                                                                                                                 //
  valueOut: function () {                                                                                            // 157
    return this.val();                                                                                               // 158
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
orion.attributes.registerAttribute('hasOne', {                                                                       // 162
  template: 'orionAttributesHasOne',                                                                                 // 163
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 164
  getSchema: function (options) {                                                                                    // 165
    return getSchema(options, false);                                                                                // 166
  },                                                                                                                 //
  valueOut: function () {                                                                                            // 168
    return this.val();                                                                                               // 169
  }                                                                                                                  //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/users.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
orion.attributes.registerAttribute('users', {                                                                        // 1
  template: 'orionAttributesHasMany',                                                                                // 2
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 3
  getSchema: function (options) {                                                                                    // 4
    options = _.extend(options, {                                                                                    // 5
      titleField: 'profile.name',                                                                                    // 6
      pluralName: i18n('attributes.users.pluralName'),                                                               // 7
      singularName: i18n('attributes.users.singularName'),                                                           // 8
      collection: Meteor.users,                                                                                      // 9
      additionalFields: ['emails.address', 'roles'],                                                                 // 10
      render: {                                                                                                      // 11
        item: function (item, escape) {                                                                              // 12
          return '<div class="usersAttribute">' + (item['profile.name'] ? '<span class="name">' + escape(item['profile.name']) + '</span>' : '') + (item['emails.address'] ? '<span class="email">' + escape(item['emails.address']) + '</span>' : '') + '</div>';
        },                                                                                                           //
        option: function (item, escape) {                                                                            // 18
          var label = item['profile.name'] || item['emails.address'];                                                // 19
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 20
          return '<div class="usersAttribute">' + '<span class="name">' + escape(label) + '</span>' + (caption ? '<span class="email">' + escape(caption) + '</span>' : '') + '</div>';
        }                                                                                                            //
      }                                                                                                              //
    });                                                                                                              //
    return orion.attribute('hasMany', {}, options);                                                                  // 28
  },                                                                                                                 //
  valueOut: function () {                                                                                            // 30
    return this.val();                                                                                               // 31
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
orion.attributes.registerAttribute('user', {                                                                         // 35
  template: 'orionAttributesHasOne',                                                                                 // 36
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 37
  getSchema: function (options) {                                                                                    // 38
    options = _.extend(options, {                                                                                    // 39
      titleField: 'profile.name',                                                                                    // 40
      collection: Meteor.users,                                                                                      // 41
      additionalFields: ['emails.address', 'roles'],                                                                 // 42
      render: {                                                                                                      // 43
        item: function (item, escape) {                                                                              // 44
          return '<div class="usersAttribute">' + (item['profile.name'] ? '<span class="name">' + escape(item['profile.name']) + '</span>' : '') + (item['emails.address'] ? '<span class="email">' + escape(item['emails.address']) + '</span>' : '') + '</div>';
        },                                                                                                           //
        option: function (item, escape) {                                                                            // 50
          var label = item['profile.name'] || item['emails.address'];                                                // 51
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 52
          return '<div class="usersAttribute">' + '<span class="name">' + escape(label) + '</span>' + (caption ? '<span class="email">' + escape(caption) + '</span>' : '') + '</div>';
        }                                                                                                            //
      }                                                                                                              //
    });                                                                                                              //
    return orion.attribute('hasOne', {}, options);                                                                   // 60
  },                                                                                                                 //
  valueOut: function () {                                                                                            // 62
    return this.val();                                                                                               // 63
  }                                                                                                                  //
});                                                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:relationships'] = {};

})();

//# sourceMappingURL=orionjs_relationships.js.map
