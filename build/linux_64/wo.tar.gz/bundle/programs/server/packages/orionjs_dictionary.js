(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Creates the dictionary mongo collection                                                                             //
 */                                                                                                                    //
orion.dictionary = new Mongo.Collection('dictionary');                                                                 // 4
                                                                                                                       //
/**                                                                                                                    //
 * To get reactively if the dictionary is active                                                                       //
 */                                                                                                                    //
orion.dictionary._isActiveDependency = new Tracker.Dependency();                                                       // 9
orion.dictionary._isActive = false;                                                                                    // 10
orion.dictionary.isActive = function () {                                                                              // 11
  this._isActiveDependency.depend();                                                                                   // 12
  return this._isActive;                                                                                               // 13
};                                                                                                                     //
                                                                                                                       //
/**                                                                                                                    //
 * Register dictionary actions and helpers for roles                                                                   //
 */                                                                                                                    //
Roles.registerAction('dictionary.update', true);                                                                       // 19
Roles.registerHelper('dictionary.allowedCategories', function () {                                                     // 20
  return orion.dictionary.simpleSchema()._firstLevelSchemaKeys;                                                        // 21
});                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 * Dictionary permissions                                                                                              //
 */                                                                                                                    //
orion.dictionary.deny({                                                                                                // 27
  /**                                                                                                                  //
   * No one can insert a dicionary object                                                                              //
   * becouse it only uses one and its created                                                                          //
   * automatically                                                                                                     //
   */                                                                                                                  //
  'insert': function (userId, doc) {                                                                                   // 33
    return true;                                                                                                       // 34
  },                                                                                                                   //
  /**                                                                                                                  //
   * No one can remove a dicionary object                                                                              //
   * becouse it only uses one.                                                                                         //
   */                                                                                                                  //
  'remove': function (userId, doc) {                                                                                   // 40
    return true;                                                                                                       // 41
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
orion.dictionary.allow({                                                                                               // 45
  'update': function (userId, doc, fields, modifier) {                                                                 // 46
    return Roles.allow(userId, 'dictionary.update', userId, doc, fields, modifier);                                    // 47
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
orion.dictionary.deny({                                                                                                // 51
  'update': function (userId, doc, fields, modifier) {                                                                 // 52
    return Roles.deny(userId, 'dictionary.update', userId, doc, fields, modifier);                                     // 53
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 * Only allow to edit allowed categories                                                                               //
 * If is set to false, can update all fields                                                                           //
 */                                                                                                                    //
orion.dictionary.deny({                                                                                                // 61
  update: function (userId, doc, fields, modifier) {                                                                   // 62
    var allowedFields = _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));            // 63
    if (allowedFields === false && _.difference(fields, allowedFields).length > 0) {                                   // 64
      return true;                                                                                                     // 65
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 * Function to add a definition to the dictionary.                                                                     //
 * This just modifies the schema of the dictionary object                                                              //
 * and adds the form in the admin.                                                                                     //
 */                                                                                                                    //
orion.dictionary.addDefinition = function (name, category, attribute) {                                                // 75
  var newSchema = this.simpleSchema() && _.clone(this.simpleSchema()._schema) || {};                                   // 76
                                                                                                                       //
  newSchema[category] = newSchema[category] || {                                                                       // 78
    type: Object,                                                                                                      // 79
    optional: true                                                                                                     // 80
  };                                                                                                                   //
                                                                                                                       //
  newSchema[category + '.' + name] = _.extend({                                                                        // 83
    optional: true                                                                                                     // 84
  }, attribute);                                                                                                       //
                                                                                                                       //
  this.attachSchema(new SimpleSchema(newSchema));                                                                      // 87
                                                                                                                       //
  if (!this._isActive) {                                                                                               // 89
    this._isActive = true;                                                                                             // 90
    this._isActiveDependency.changed();                                                                                // 91
  }                                                                                                                    //
};                                                                                                                     //
                                                                                                                       //
/**                                                                                                                    //
 * Returns the value of the definition.                                                                                //
 * If the definition doesn't exists it                                                                                 //
 * returns the defaultValue                                                                                            //
 */                                                                                                                    //
orion.dictionary.get = function (path, defaultValue) {                                                                 // 100
  // Sets empty string to avoid problems on templates                                                                  //
  defaultValue = !defaultValue || defaultValue instanceof Spacebars.kw ? undefined : defaultValue;                     // 102
                                                                                                                       //
  if (!defaultValue && orion.dictionary.simpleSchema()) {                                                              // 104
    var def = orion.dictionary.simpleSchema()._schema[path];                                                           // 105
    if (def && _.has(def, 'defaultValue')) {                                                                           // 106
      defaultValue = _.isFunction(def.defaultValue) ? def.defaultValue() : def.defaultValue;                           // 107
    }                                                                                                                  //
  }                                                                                                                    //
                                                                                                                       //
  var dictionaryId = Meteor.isServer && process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {};               // 111
  var dictionary = this.findOne(dictionaryId);                                                                         // 112
  return orion.helpers.searchObjectWithDots(dictionary, path) || defaultValue;                                         // 113
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/admin.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * Init the template name variable                                                                                     //
 */                                                                                                                    //
ReactiveTemplates.request('dictionaryUpdate');                                                                         // 4
                                                                                                                       //
/**                                                                                                                    //
 * Register the route                                                                                                  //
 */                                                                                                                    //
RouterLayer.route('/admin/dictionary', {                                                                               // 9
  layout: 'layout',                                                                                                    // 10
  template: 'dictionaryUpdate',                                                                                        // 11
  name: 'dictionary.update',                                                                                           // 12
  reactiveTemplates: true                                                                                              // 13
});                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 * Ensure user is logged in                                                                                            //
 */                                                                                                                    //
orion.accounts.addProtectedRoute('dictionary.update');                                                                 // 19
                                                                                                                       //
/**                                                                                                                    //
 * Register the link                                                                                                   //
 */                                                                                                                    //
Tracker.autorun(function () {                                                                                          // 24
  if (!orion.dictionary.isActive() || Meteor.isServer) return;                                                         // 25
                                                                                                                       //
  orion.links.add({                                                                                                    // 27
    index: 10,                                                                                                         // 28
    identifier: 'dictionary-update',                                                                                   // 29
    title: i18n('dictionary.update.title'),                                                                            // 30
    routeName: 'dictionary.update',                                                                                    // 31
    activeRouteRegex: 'dictionary',                                                                                    // 32
    permission: 'dictionary.update'                                                                                    // 33
  });                                                                                                                  //
});                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    //
 * Create the template helpers for a dictionary                                                                        //
 */                                                                                                                    //
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 41
                                                                                                                       //
  ReactiveTemplates.onRendered('dictionaryUpdate', function () {                                                       // 43
    var defaultCategory = _.first(_.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories')));
    Session.set('dictionaryUpdateCurrentCategory', defaultCategory);                                                   // 45
  });                                                                                                                  //
                                                                                                                       //
  ReactiveTemplates.events('dictionaryUpdate', {                                                                       // 48
    'click [data-category]': function (event) {                                                                        // 49
      var newCategory = $(event.currentTarget).attr('data-category');                                                  // 50
      Session.set('dictionaryUpdateCurrentCategory', newCategory);                                                     // 51
    }                                                                                                                  //
  });                                                                                                                  //
                                                                                                                       //
  ReactiveTemplates.helpers('dictionaryUpdate', {                                                                      // 55
    getDoc: function () {                                                                                              // 56
      return orion.dictionary.findOne();                                                                               // 57
    },                                                                                                                 //
    currentCategory: function () {                                                                                     // 59
      return Session.get('dictionaryUpdateCurrentCategory');                                                           // 60
    },                                                                                                                 //
    getCategories: function () {                                                                                       // 62
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));                       // 63
    }                                                                                                                  //
  });                                                                                                                  //
}                                                                                                                      //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary_server.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * If its on server, inserts the dictionary object                                                                     //
 */                                                                                                                    //
if (orion.dictionary.find(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {}).count() === 0) {            // 4
  // orion.dictionary.remove(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{});                                //
  orion.dictionary.insert(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {}, function () {               // 6
    console.log("Orion dictionary initialized");                                                                       // 7
  });                                                                                                                  //
}                                                                                                                      //
                                                                                                                       //
/**                                                                                                                    //
 * Publications of the dictionary                                                                                      //
 */                                                                                                                    //
Meteor.publish('orion_dictionary', function () {                                                                       // 14
  return orion.dictionary.find(process.env.ORION_APPID ? { _id: process.env.ORION_APPID } : {});                       // 15
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:dictionary'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_dictionary.js.map
