(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Inject = Package['meteorhacks:inject-initial'].Inject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Tabular, UsersEmailsSchema, UsersPasswordSchema, orion;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/tabular.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Tabular = null;                                                                                                   // 1
                                                                                                                  //
if (Package['nicolaslopezj:tabular-materialize']) {                                                               // 3
  Tabular = Package['nicolaslopezj:tabular-materialize'].Tabular;                                                 // 4
}                                                                                                                 //
                                                                                                                  //
if (Package['aldeed:tabular']) {                                                                                  // 7
  Tabular = Package['aldeed:tabular'].Tabular;                                                                    // 8
}                                                                                                                 //
                                                                                                                  //
if (!Tabular) {                                                                                                   // 11
  throw new Meteor.Error('orion', 'You must install tabular to use this package');                                // 12
}                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
orion.accounts = {};                                                                                              // 1
                                                                                                                  //
/**                                                                                                               //
 * Initialize the profile schema option with its default value                                                    //
 */                                                                                                               //
Options.init('profileSchema', {                                                                                   // 6
  name: {                                                                                                         // 7
    type: String,                                                                                                 // 8
    label: orion.helpers.getTranslation('accounts.schema.profile.name')                                           // 9
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Updates the profile schema reactively                                                                          //
 */                                                                                                               //
Tracker.autorun(function () {                                                                                     // 16
  orion.accounts.profileSchema = new SimpleSchema({                                                               // 17
    profile: {                                                                                                    // 18
      type: new SimpleSchema(Options.get('profileSchema'))                                                        // 19
    }                                                                                                             //
  });                                                                                                             //
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Initialize accounts options                                                                                    //
 * If there is no admin, we allow to create accounts                                                              //
 */                                                                                                               //
Options.init('defaultRoles', []);                                                                                 // 28
Options.init('forbidClientAccountCreation', true);                                                                // 29
                                                                                                                  //
/**                                                                                                               //
 * We will use listen instead of tracker because on client tracker starts after meteor.startup                    //
 */                                                                                                               //
Options.listen('forbidClientAccountCreation', function (value) {                                                  // 34
  AccountsTemplates.configure({                                                                                   // 35
    forbidClientAccountCreation: orion.adminExists && value                                                       // 36
  });                                                                                                             //
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Adds the "name" field to the sign up form                                                                      //
 */                                                                                                               //
AccountsTemplates.addField({                                                                                      // 43
  _id: 'name',                                                                                                    // 44
  type: 'text',                                                                                                   // 45
  displayName: Meteor.isClient ? i18n('accounts.register.fields.name') : 'Name',                                  // 46
  placeholder: Meteor.isClient ? i18n('accounts.register.fields.name') : 'Your Name',                             // 47
  required: true                                                                                                  // 48
});                                                                                                               //
                                                                                                                  //
UsersEmailsSchema = new SimpleSchema({                                                                            // 51
  emails: {                                                                                                       // 52
    type: [Object],                                                                                               // 53
    optional: true,                                                                                               // 54
    label: orion.helpers.getTranslation('accounts.schema.emails.title')                                           // 55
  },                                                                                                              //
  'emails.$.address': {                                                                                           // 57
    type: String,                                                                                                 // 58
    regEx: SimpleSchema.RegEx.Email,                                                                              // 59
    label: orion.helpers.getTranslation('accounts.schema.emails.address')                                         // 60
  },                                                                                                              //
  'emails.$.verified': {                                                                                          // 62
    type: Boolean,                                                                                                // 63
    label: orion.helpers.getTranslation('accounts.schema.emails.verified')                                        // 64
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
SimpleSchema.messages({                                                                                           // 68
  'passwordMismatch': i18n('global.passwordNotMatch')                                                             // 69
});                                                                                                               //
                                                                                                                  //
UsersPasswordSchema = new SimpleSchema({                                                                          // 72
  password: {                                                                                                     // 73
    type: String,                                                                                                 // 74
    label: orion.helpers.getTranslation('accounts.schema.password.new'),                                          // 75
    min: 8,                                                                                                       // 76
    autoform: {                                                                                                   // 77
      type: 'password'                                                                                            // 78
    }                                                                                                             //
  },                                                                                                              //
  confirm: {                                                                                                      // 81
    type: String,                                                                                                 // 82
    label: orion.helpers.getTranslation('accounts.schema.password.confirm'),                                      // 83
    min: 8,                                                                                                       // 84
    autoform: {                                                                                                   // 85
      type: 'password'                                                                                            // 86
    },                                                                                                            //
    custom: function () {                                                                                         // 88
      if (this.value !== this.field('password').value) {                                                          // 89
        return 'passwordMismatch';                                                                                // 90
      }                                                                                                           //
    }                                                                                                             //
  }                                                                                                               //
});                                                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/authentication/login.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Init the template name variable                                                                                //
 */                                                                                                               //
ReactiveTemplates.request('login');                                                                               // 4
                                                                                                                  //
RouterLayer.route('/admin/login', {                                                                               // 6
  name: 'admin.login',                                                                                            // 7
  layout: 'outAdminLayout',                                                                                       // 8
  template: 'login',                                                                                              // 9
  reactiveTemplates: true                                                                                         // 10
});                                                                                                               //
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 13
  ReactiveTemplates.onRendered('login', function () {                                                             // 14
    this.autorun(function () {                                                                                    // 15
      if (Meteor.userId()) {                                                                                      // 16
        var ref = RouterLayer.getQueryParam('ref') || RouterLayer.pathFor('admin');                               // 17
        RouterLayer.go(ref);                                                                                      // 18
      }                                                                                                           //
    });                                                                                                           //
  });                                                                                                             //
}                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/authentication/secure-routes.js                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * To set the secure routes                                                                                       //
 */                                                                                                               //
Options.init('ensureSignedIn', []);                                                                               // 4
                                                                                                                  //
Tracker.autorun(function () {                                                                                     // 6
  if (!Meteor.isClient) return;                                                                                   // 7
  var routes = Options.get('ensureSignedIn');                                                                     // 8
  if (RouterLayer.router == 'iron-router') {                                                                      // 9
    RouterLayer.ironRouter.onBeforeAction(function () {                                                           // 10
      if (RouterLayer.ironRouter.current && _.contains(routes, RouterLayer.ironRouter.current().route.getName()) && !Meteor.userId()) {
        var path = null;                                                                                          // 12
        Tracker.nonreactive(function () {                                                                         // 13
          path = RouterLayer.ironRouter.current().location.get().path;                                            // 14
        });                                                                                                       //
        this.router.go('admin.login', {}, { replaceState: true, query: { ref: path } });                          // 16
        return;                                                                                                   // 17
      }                                                                                                           //
      this.next();                                                                                                // 19
    });                                                                                                           //
  } else if (RouterLayer.router == 'flow-router') {                                                               //
    RouterLayer.flowRouter.triggers.enter([function (context, redirect) {                                         // 22
      Tracker.autorun(function () {                                                                               // 23
        if (_.contains(routes, RouterLayer.flowRouter.getRouteName()) && !Meteor.userId()) {                      // 24
          FlowRouter.withReplaceState(function () {                                                               // 25
            RouterLayer.flowRouter.go('admin.login', {}, { ref: FlowRouter.current().path });                     // 26
          });                                                                                                     //
        }                                                                                                         //
      });                                                                                                         //
    }]);                                                                                                          //
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
orion.accounts.addProtectedRoute = function (routeName) {                                                         // 34
  Options.arrayPush('ensureSignedIn', routeName);                                                                 // 35
};                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/my-account/admin.js                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Display account settings                                                                                       //
 */                                                                                                               //
ReactiveTemplates.request('myAccount.index');                                                                     // 4
ReactiveTemplates.request('myAccount.password');                                                                  // 5
ReactiveTemplates.request('myAccount.profile');                                                                   // 6
                                                                                                                  //
/**                                                                                                               //
 * Register the route                                                                                             //
 */                                                                                                               //
RouterLayer.route('/admin/my-account', {                                                                          // 11
  layout: 'layout',                                                                                               // 12
  template: 'myAccount.index',                                                                                    // 13
  name: 'myAccount.index',                                                                                        // 14
  reactiveTemplates: true                                                                                         // 15
});                                                                                                               //
orion.accounts.addProtectedRoute('myAccount.index');                                                              // 17
                                                                                                                  //
/**                                                                                                               //
 * Allow password change                                                                                          //
 */                                                                                                               //
AccountsTemplates.configure({                                                                                     // 22
  enablePasswordChange: true                                                                                      // 23
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Register the route                                                                                             //
 */                                                                                                               //
RouterLayer.route('/admin/my-account/change-password', {                                                          // 29
  layout: 'layout',                                                                                               // 30
  template: 'myAccount.password',                                                                                 // 31
  name: 'myAccount.password',                                                                                     // 32
  reactiveTemplates: true                                                                                         // 33
});                                                                                                               //
orion.accounts.addProtectedRoute('myAccount.password');                                                           // 35
                                                                                                                  //
/**                                                                                                               //
 * To update the profile                                                                                          //
 */                                                                                                               //
RouterLayer.route('/admin/my-account/profile', {                                                                  // 40
  layout: 'layout',                                                                                               // 41
  template: 'myAccount.profile',                                                                                  // 42
  name: 'myAccount.profile',                                                                                      // 43
  reactiveTemplates: true                                                                                         // 44
});                                                                                                               //
orion.accounts.addProtectedRoute('myAccount.profile');                                                            // 46
                                                                                                                  //
/**                                                                                                               //
 * Create the template events account settings                                                                    //
 */                                                                                                               //
if (Meteor.isClient) {                                                                                            // 51
  /**                                                                                                             //
   * Register the link                                                                                            //
   */                                                                                                             //
  Tracker.autorun(function () {                                                                                   // 55
    orion.links.add({                                                                                             // 56
      identifier: 'myAccount',                                                                                    // 57
      title: Meteor.user() && Meteor.user().profile && Meteor.user().profile.name || 'Account',                   // 58
      activeRouteRegex: 'myAccount'                                                                               // 59
    });                                                                                                           //
    orion.links.add({                                                                                             // 61
      index: 20,                                                                                                  // 62
      identifier: 'myAccount-index',                                                                              // 63
      parent: 'myAccount',                                                                                        // 64
      title: i18n('accounts.myAccount.title'),                                                                    // 65
      routeName: 'myAccount.index',                                                                               // 66
      activeRouteRegex: 'myAccount.index'                                                                         // 67
    });                                                                                                           //
    orion.links.add({                                                                                             // 69
      index: 50,                                                                                                  // 70
      identifier: 'myAccount-updateProfile',                                                                      // 71
      parent: 'myAccount',                                                                                        // 72
      title: i18n('accounts.updateProfile.title'),                                                                // 73
      routeName: 'myAccount.profile',                                                                             // 74
      activeRouteRegex: 'myAccount.profile'                                                                       // 75
    });                                                                                                           //
    orion.links.add({                                                                                             // 77
      index: 100,                                                                                                 // 78
      identifier: 'myAccount-changePassword',                                                                     // 79
      parent: 'myAccount',                                                                                        // 80
      title: i18n('accounts.changePassword.title'),                                                               // 81
      routeName: 'myAccount.password',                                                                            // 82
      activeRouteRegex: 'myAccount.password'                                                                      // 83
    });                                                                                                           //
  });                                                                                                             //
                                                                                                                  //
  ReactiveTemplates.events('myAccount.index', {                                                                   // 87
    'click .logout': function () {                                                                                // 88
      return Meteor.logout();                                                                                     // 89
    }                                                                                                             //
  });                                                                                                             //
                                                                                                                  //
  ReactiveTemplates.helpers('myAccount.profile', {                                                                // 93
    getDoc: function () {                                                                                         // 94
      return Meteor.user();                                                                                       // 95
    },                                                                                                            //
    getSchema: function () {                                                                                      // 97
      return orion.accounts.profileSchema;                                                                        // 98
    }                                                                                                             //
  });                                                                                                             //
}                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/accounts.js                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Register the account index action                                                                              //
 */                                                                                                               //
Roles.registerAction('accounts.index', true);                                                                     // 4
                                                                                                                  //
/**                                                                                                               //
 * Can the user update user users roles?                                                                          //
 */                                                                                                               //
Roles.registerAction('accounts.update.roles', true);                                                              // 9
Roles.registerAction('accounts.update.password', true);                                                           // 10
Roles.registerAction('accounts.update.emails', true);                                                             // 11
Roles.registerAction('accounts.update.profile', true);                                                            // 12
Roles.registerAction('accounts.remove', true);                                                                    // 13
                                                                                                                  //
/**                                                                                                               //
 * Register the index filter for the accounts.list                                                                //
 */                                                                                                               //
Roles.registerHelper('accounts.indexFilter', {});                                                                 // 18
                                                                                                                  //
/**                                                                                                               //
 * To set the actions for the admin                                                                               //
 */                                                                                                               //
orion.accounts._adminUsersButtons = [];                                                                           // 23
                                                                                                                  //
/**                                                                                                               //
 * Add buttons to the list of users in the admin                                                                  //
 */                                                                                                               //
orion.accounts.addAdminUsersButton = function (button) {                                                          // 28
  Tracker.nonreactive(function () {                                                                               // 29
    var current = _.findWhere(orion.accounts._adminUsersButtons, {                                                // 30
      route: button.route,                                                                                        // 31
      meteorMethod: button.meteorMethod                                                                           // 32
    });                                                                                                           //
    if (current) {                                                                                                // 34
      orion.accounts._adminUsersButtons = _.without(orion.accounts._adminUsersButtons, current);                  // 35
    }                                                                                                             //
  });                                                                                                             //
                                                                                                                  //
  check(button, {                                                                                                 // 39
    title: String,                                                                                                // 40
    route: Match.Optional(String),                                                                                // 41
    meteorMethod: Match.Optional(String),                                                                         // 42
    shouldShow: Match.Optional(Function),                                                                         // 43
    onClick: Match.Optional(Function)                                                                             // 44
  });                                                                                                             //
                                                                                                                  //
  orion.accounts._adminUsersButtons.push(button);                                                                 // 47
};                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/admin.js                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Display account settings                                                                                       //
 */                                                                                                               //
ReactiveTemplates.request('accounts.index');                                                                      // 4
ReactiveTemplates.request('accounts.update');                                                                     // 5
                                                                                                                  //
/**                                                                                                               //
 * Register the route                                                                                             //
 */                                                                                                               //
RouterLayer.route('/admin/accounts', {                                                                            // 10
  layout: 'layout',                                                                                               // 11
  template: 'accounts.index',                                                                                     // 12
  name: 'accounts.index',                                                                                         // 13
  reactiveTemplates: true                                                                                         // 14
});                                                                                                               //
orion.accounts.addProtectedRoute('accounts.index');                                                               // 16
                                                                                                                  //
/**                                                                                                               //
 * Register the link                                                                                              //
 */                                                                                                               //
if (Meteor.isClient) {                                                                                            // 21
  Tracker.autorun(function () {                                                                                   // 22
    orion.links.add({                                                                                             // 23
      index: 80,                                                                                                  // 24
      identifier: 'accounts-index',                                                                               // 25
      title: i18n('accounts.index.title'),                                                                        // 26
      routeName: 'accounts.index',                                                                                // 27
      activeRouteRegex: 'accounts',                                                                               // 28
      permission: 'accounts.index'                                                                                // 29
    });                                                                                                           //
  });                                                                                                             //
}                                                                                                                 //
                                                                                                                  //
/**                                                                                                               //
 * Tabular table                                                                                                  //
 */                                                                                                               //
var tabularOptions = {                                                                                            // 37
  name: 'AccountsIndex',                                                                                          // 38
  stateSave: true,                                                                                                // 39
  collection: Meteor.users,                                                                                       // 40
  allow: function (userId) {                                                                                      // 41
    return Roles.userHasPermission(userId, 'accounts.index'); // don't allow this person to subscribe to the data
  },                                                                                                              //
  selector: function (userId) {                                                                                   // 44
    var selectors = Roles.helper(userId, 'accounts.indexFilter');                                                 // 45
    return { $or: selectors };                                                                                    // 46
  },                                                                                                              //
  pub: 'adminAccountsIndexTabular',                                                                               // 48
  columns: [{                                                                                                     // 49
    data: 'profile.name',                                                                                         // 51
    title: orion.helpers.getTranslation('accounts.index.tableTitles.name'),                                       // 52
    render: function (val, type, doc) {                                                                           // 53
      return val ? val : '<span class="grey-text help-block">' + i18n('accounts.index.noName') + '</span>';       // 54
    }                                                                                                             //
  }, {                                                                                                            //
    data: 'usedServices',                                                                                         // 58
    title: orion.helpers.getTranslation('accounts.index.tableTitles.services'),                                   // 59
    render: function (val, type, doc) {                                                                           // 60
      var services = _.without(val, 'email', 'resume');                                                           // 61
      if (!services.length) {                                                                                     // 62
        var title = i18n('accounts.index.actions.sendEnrollmentEmail');                                           // 63
        return '<button class="btn btn-danger red btn-xs send-enrollment-email-btn" data-user="' + doc._id + '">' + title + '</button>';
      }                                                                                                           //
      return services.map(function (service) {                                                                    // 66
        return '<span class="label label-primary blue">' + service + '</span>';                                   // 67
      }).join('');                                                                                                //
    }                                                                                                             //
  }, {                                                                                                            //
    data: 'emails',                                                                                               // 72
    title: orion.helpers.getTranslation('accounts.index.tableTitles.email'),                                      // 73
    render: function (val, type, doc) {                                                                           // 74
      return val && val[0] && val[0].address;                                                                     // 75
    }                                                                                                             //
  }, {                                                                                                            //
    data: 'roles',                                                                                                // 79
    title: orion.helpers.getTranslation('accounts.index.tableTitles.roles'),                                      // 80
    render: function (val, type, doc) {                                                                           // 81
      var roles = Roles._collection ? doc.roles() : val || [];                                                    // 82
      return roles.map(function (role) {                                                                          // 83
        return '<span class="label label-danger red">' + role + '</span>';                                        // 84
      }).join('');                                                                                                //
    }                                                                                                             //
  }, {                                                                                                            //
    title: orion.helpers.getTranslation('accounts.index.tableTitles.actions'),                                    // 89
    render: function (val, type, doc) {                                                                           // 90
      return _.filter(orion.accounts._adminUsersButtons, function (value, key, list) {                            // 91
        if (typeof value.shouldShow != 'function') {                                                              // 92
          return true;                                                                                            // 93
        }                                                                                                         //
        return value.shouldShow(doc);                                                                             // 95
      }).map(function (button, index) {                                                                           //
        return '<a class="btn btn-default btn-xs waves-effect waves-light light-blue accent-4 user-btn-action" data-button-index="' + index + '" data-user="' + doc._id + '">' + button.title + '</a>';
      }).join('');                                                                                                //
    }                                                                                                             //
  }]                                                                                                              //
};                                                                                                                //
                                                                                                                  //
Tracker.autorun(function () {                                                                                     // 104
  tabularOptions.columns.map(function (column) {                                                                  // 105
    if (_.isFunction(column.title)) {                                                                             // 106
      column.langTitle = column.title;                                                                            // 107
    }                                                                                                             //
    if (_.isFunction(column.langTitle)) {                                                                         // 109
      column.title = column.langTitle();                                                                          // 110
    }                                                                                                             //
    return column;                                                                                                // 112
  });                                                                                                             //
  orion.accounts.indexTabularTable = new Tabular.Table(tabularOptions);                                           // 114
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Edit user                                                                                                      //
 */                                                                                                               //
RouterLayer.route('/admin/accounts/:_id/update', {                                                                // 120
  layout: 'layout',                                                                                               // 121
  template: 'accounts.update',                                                                                    // 122
  name: 'accounts.update',                                                                                        // 123
  reactiveTemplates: true                                                                                         // 124
});                                                                                                               //
orion.accounts.addProtectedRoute('accounts.update');                                                              // 126
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 128
  Tracker.autorun(function () {                                                                                   // 129
    orion.accounts.addAdminUsersButton({                                                                          // 130
      title: i18n('accounts.index.actions.edit'),                                                                 // 131
      route: 'accounts.update',                                                                                   // 132
      shouldShow: function () {                                                                                   // 133
        return Roles.userHasPermission(Meteor.userId(), 'accounts.update.roles');                                 // 134
      }                                                                                                           //
    });                                                                                                           //
  });                                                                                                             //
}                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/invite.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Can the user update user users roles?                                                                          //
 */                                                                                                               //
Roles.registerAction('accounts.showCreate', true);                                                                // 4
Roles.registerAction('accounts.create', true);                                                                    // 5
Roles.registerHelper('accounts.allowedRoles', function () {                                                       // 6
  return Roles.availableRoles();                                                                                  // 7
});                                                                                                               //
Roles.registerHelper('accounts.deniedRoles', []);                                                                 // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/admin.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * invite users                                                                                                   //
 */                                                                                                               //
ReactiveTemplates.request('accounts.create');                                                                     // 4
                                                                                                                  //
RouterLayer.route('/admin/accounts/create', {                                                                     // 6
  layout: 'layout',                                                                                               // 7
  template: 'accounts.create',                                                                                    // 8
  name: 'accounts.create',                                                                                        // 9
  reactiveTemplates: true                                                                                         // 10
});                                                                                                               //
orion.accounts.addProtectedRoute('accounts.create');                                                              // 12
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 14
  ReactiveTemplates.onRendered('accounts.create', function () {                                                   // 15
    Session.set('accounts.create.invitationId', null);                                                            // 16
    Session.set('accounts.create.method', 'invitation');                                                          // 17
  });                                                                                                             //
  ReactiveTemplates.helpers('accounts.create', {                                                                  // 19
    roles: function () {                                                                                          // 20
      var allowed = _.union.apply(this, Roles.helper(Meteor.userId(), 'accounts.allowedRoles'));                  // 21
      var denied = _.union.apply(this, Roles.helper(Meteor.userId(), 'accounts.deniedRoles'));                    // 22
      return _.difference(allowed, denied);                                                                       // 23
    },                                                                                                            //
    invitationId: function () {                                                                                   // 25
      return Session.get('accounts.create.invitationId');                                                         // 26
    },                                                                                                            //
    email: function () {                                                                                          // 28
      return Session.get('accounts.create.email');                                                                // 29
    },                                                                                                            //
    createWithInvitation: function () {                                                                           // 31
      return Session.get('accounts.create.method') == 'invitation';                                               // 32
    }                                                                                                             //
  });                                                                                                             //
  ReactiveTemplates.events('accounts.create', {                                                                   // 35
    'submit form.create': function (event, template) {                                                            // 36
      var roles = [];                                                                                             // 37
      template.$('input[role]').each(function (index, val) {                                                      // 38
        var role = $(this).attr('role');                                                                          // 39
        if ($(this).is(':checked')) {                                                                             // 40
          roles.push(role);                                                                                       // 41
        }                                                                                                         //
      });                                                                                                         //
                                                                                                                  //
      var email = template.$('input[type="email"]').val();                                                        // 45
      var method = template.$('input[name="createMethod"]:checked').val();                                        // 46
      var options = {};                                                                                           // 47
                                                                                                                  //
      if (method == 'invitation') {                                                                               // 49
        options = {                                                                                               // 50
          email: email,                                                                                           // 51
          roles: roles                                                                                            // 52
        };                                                                                                        //
      } else if (method == 'now') {                                                                               //
        var name = template.$('input[name="name"]').val();                                                        // 55
        var password = template.$('input[name="password"]').val();                                                // 56
        var confirm = template.$('input[name="confirm"]').val();                                                  // 57
        if (password != confirm) {                                                                                // 58
          alert(i18n('global.passwordNotMatch'));                                                                 // 59
          return false;                                                                                           // 60
        }                                                                                                         //
        options = {                                                                                               // 62
          email: email,                                                                                           // 63
          password: password,                                                                                     // 64
          name: name,                                                                                             // 65
          roles: roles                                                                                            // 66
        };                                                                                                        //
      }                                                                                                           //
                                                                                                                  //
      Meteor.call('accountsCreateUser', options, function (error, result) {                                       // 70
        if (error) {                                                                                              // 71
          alert(error.reason);                                                                                    // 72
          console.log(error);                                                                                     // 73
        } else {                                                                                                  //
          RouterLayer.go('accounts.index');                                                                       // 75
        }                                                                                                         //
      });                                                                                                         //
      return false;                                                                                               // 78
    },                                                                                                            //
    'change input[name="createMethod"]': function (event, template) {                                             // 80
      Session.set('accounts.create.method', $(event.currentTarget).val());                                        // 81
    },                                                                                                            //
    'click .btn-invite-another': function () {                                                                    // 83
      Session.set('accounts.create.invitationId', null);                                                          // 84
    }                                                                                                             //
  });                                                                                                             //
}                                                                                                                 //
                                                                                                                  //
/**                                                                                                               //
 * Register with invitation                                                                                       //
 */                                                                                                               //
ReactiveTemplates.request('registerWithInvitation');                                                              // 92
RouterLayer.route('/register/invitation/:_id', {                                                                  // 93
  layout: 'outAdminLayout',                                                                                       // 94
  template: 'registerWithInvitation',                                                                             // 95
  name: 'registerWithInvitation',                                                                                 // 96
  reactiveTemplates: true                                                                                         // 97
});                                                                                                               //
                                                                                                                  //
if (Meteor.isClient) {                                                                                            // 100
                                                                                                                  //
  ReactiveTemplates.onRendered('registerWithInvitation', function () {                                            // 102
    if (Meteor.userId()) {                                                                                        // 103
      RouterLayer.go('admin');                                                                                    // 104
    }                                                                                                             //
    this.subscribe('invitation', RouterLayer.getParam('_id'));                                                    // 106
    Session.set('registerWithInvitationError', null);                                                             // 107
  });                                                                                                             //
                                                                                                                  //
  ReactiveTemplates.helpers('registerWithInvitation', {                                                           // 110
    invitation: function () {                                                                                     // 111
      return orion.accounts.invitations.findOne(RouterLayer.getParam('_id'));                                     // 112
    },                                                                                                            //
    error: function () {                                                                                          // 114
      return Session.get('registerWithInvitationError');                                                          // 115
    }                                                                                                             //
  });                                                                                                             //
                                                                                                                  //
  ReactiveTemplates.events('registerWithInvitation', {                                                            // 119
    'submit form': function (event, template) {                                                                   // 120
      event.preventDefault();                                                                                     // 121
      Session.set('registerWithInvitationError', null);                                                           // 122
                                                                                                                  //
      var email = template.$("[name='email']").val(),                                                             // 124
          name = template.$("[name='name']").val(),                                                               //
          password = template.$("[name='password']").val(),                                                       //
          passwordConfirm = template.$("[name='password-confirm']").val();                                        //
                                                                                                                  //
      if (!/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)) {
        Session.set('registerWithInvitationError', i18n('accounts.register.messages.invalidEmail'));              // 130
        return;                                                                                                   // 131
      }                                                                                                           //
                                                                                                                  //
      if (password != passwordConfirm) {                                                                          // 134
        Session.set('registerWithInvitationError', i18n('global.passwordNotMatch'));                              // 135
        return;                                                                                                   // 136
      }                                                                                                           //
                                                                                                                  //
      Meteor.call('registerWithInvitation', {                                                                     // 139
        invitationId: Router.current().params._id,                                                                // 140
        email: email,                                                                                             // 141
        password: password,                                                                                       // 142
        name: name                                                                                                // 143
      }, function (error, result) {                                                                               //
        if (error) {                                                                                              // 145
          Session.set('registerWithInvitationError', error.reason);                                               // 146
          console.log(error);                                                                                     // 147
        } else {                                                                                                  //
          Meteor.loginWithPassword(email, password, function (error) {                                            // 149
            if (error) {                                                                                          // 150
              Session.set('registerWithInvitationError', error.reason);                                           // 151
              console.log(error);                                                                                 // 152
            } else {                                                                                              //
              RouterLayer.go('admin');                                                                            // 154
            }                                                                                                     //
          });                                                                                                     //
        }                                                                                                         //
      });                                                                                                         //
    }                                                                                                             //
  });                                                                                                             //
}                                                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts_server.js                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               //
 * Sets the default permissions to new users                                                                      //
 */                                                                                                               //
Meteor.users.after.insert(function (userId, doc) {                                                                // 4
  var curUserId = doc._id;                                                                                        // 5
                                                                                                                  //
  if (orion.adminExists) {                                                                                        // 7
    // if there is a admin created we will set the default roles.                                                 //
    var defaultRoles = Options.get('defaultRoles');                                                               // 9
    Roles.addUserToRoles(curUserId, defaultRoles);                                                                // 10
  } else {                                                                                                        //
    // If there is no admin, we will add the admin role to this new user.                                         //
    Roles.addUserToRoles(curUserId, 'admin');                                                                     // 13
    // Pass to the client if the admin exists                                                                     //
    orion.adminExists = true;                                                                                     // 15
    Inject.obj('adminExists', { exists: true });                                                                  // 16
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
/**                                                                                                               //
 * Pass to the client if there is a admin account                                                                 //
 */                                                                                                               //
if (Roles._collection) {                                                                                          // 24
  orion.adminExists = Roles._collection.find({ roles: 'admin' }).count() !== 0;                                   // 25
} else {                                                                                                          //
  orion.adminExists = Meteor.users.find({ roles: 'admin' }).count() !== 0;                                        // 27
}                                                                                                                 //
Inject.obj('adminExists', { exists: orion.adminExists });                                                         // 29
AccountsTemplates.configure({                                                                                     // 30
  forbidClientAccountCreation: !!orion.adminExists                                                                // 31
});                                                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/server.js                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish('adminAccountsIndexTabular', function (tableName, ids, fields) {                                   // 1
  check(tableName, String);                                                                                       // 2
  check(ids, Array);                                                                                              // 3
  check(fields, Match.Optional(Object));                                                                          // 4
                                                                                                                  //
  if (!Roles.userHasPermission(this.userId, 'accounts.index')) {                                                  // 6
    return [];                                                                                                    // 7
  }                                                                                                               //
                                                                                                                  //
  var self = this;                                                                                                // 10
  var transform = function (user) {                                                                               // 11
    user.usedServices = _.keys(user.services);                                                                    // 12
    delete user.services;                                                                                         // 13
    return user;                                                                                                  // 14
  };                                                                                                              //
                                                                                                                  //
  fields.services = 1;                                                                                            // 17
  fields.roles = 1;                                                                                               // 18
  var usersHandle = Meteor.users.find({ _id: { $in: ids } }, { fields: fields }).observe({                        // 19
    added: function (user) {                                                                                      // 20
      self.added('users', user._id, transform(user));                                                             // 21
    },                                                                                                            //
    changed: function (user) {                                                                                    // 23
      self.changed('users', user._id, transform(user));                                                           // 24
    },                                                                                                            //
    removed: function (user) {                                                                                    // 26
      self.removed('users', user._id);                                                                            // 27
    }                                                                                                             //
  });                                                                                                             //
                                                                                                                  //
  self.onStop(function () {                                                                                       // 31
    usersHandle.stop();                                                                                           // 32
  });                                                                                                             //
                                                                                                                  //
  if (Roles._collection) {                                                                                        // 35
    var rolesHandle = Roles._collection.find({ userId: { $in: ids } }).observe({                                  // 36
      added: function (role) {                                                                                    // 37
        self.added('roles', role._id, role);                                                                      // 38
      },                                                                                                          //
      changed: function (role) {                                                                                  // 40
        self.changed('roles', role._id, role);                                                                    // 41
      },                                                                                                          //
      removed: function (role) {                                                                                  // 43
        self.removed('roles', role._id);                                                                          // 44
      }                                                                                                           //
    });                                                                                                           //
                                                                                                                  //
    self.onStop(function () {                                                                                     // 48
      rolesHandle.stop();                                                                                         // 49
    });                                                                                                           //
  }                                                                                                               //
                                                                                                                  //
  self.ready();                                                                                                   // 53
});                                                                                                               //
                                                                                                                  //
Meteor.publish('adminAccountsUpdateRoles', function (userId) {                                                    // 56
  check(userId, String);                                                                                          // 57
  if (!Roles.userHasPermission(this.userId, 'accounts.update.roles')) {                                           // 58
    return [];                                                                                                    // 59
  }                                                                                                               //
  if (Roles._collection) {                                                                                        // 61
    return [Meteor.users.find(userId, { fields: { services: 0 } }), Roles._collection.find({ userId: userId })];  // 62
  } else {                                                                                                        //
    return Meteor.users.find(userId, { fields: { services: 0 } });                                                // 67
  }                                                                                                               //
});                                                                                                               //
                                                                                                                  //
Meteor.methods({                                                                                                  // 71
  updateRoles: function (userId, roles) {                                                                         // 72
    check(userId, String);                                                                                        // 73
    check(roles, Array);                                                                                          // 74
    if (!Roles.userHasPermission(this.userId, 'accounts.update.roles')) {                                         // 75
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 76
    }                                                                                                             //
    var allowed = _.union.apply(this, Roles.helper(this.userId, 'accounts.allowedRoles'));                        // 78
    var denied = _.union.apply(this, Roles.helper(this.userId, 'accounts.deniedRoles'));                          // 79
    var finalRoles = _.difference(allowed, denied);                                                               // 80
                                                                                                                  //
    if (_.difference(roles, finalRoles).length !== 0) {                                                           // 82
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 83
    }                                                                                                             //
                                                                                                                  //
    Roles.setUserRoles(userId, roles);                                                                            // 86
  },                                                                                                              //
  orionAccountsUpdatePassword: function (modifier, userId) {                                                      // 88
    if (!Roles.userHasPermission(this.userId, 'accounts.update.password', userId)) {                              // 89
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 90
    }                                                                                                             //
    var options = modifier.$set;                                                                                  // 92
    check(options, UsersPasswordSchema);                                                                          // 93
    Accounts.setPassword(userId, options.password, { logout: true });                                             // 94
  },                                                                                                              //
  orionAccountsUpdateEmails: function (modifier, userId) {                                                        // 96
    if (!Roles.userHasPermission(this.userId, 'accounts.update.emails', userId)) {                                // 97
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 98
    }                                                                                                             //
    Meteor.users.update(userId, modifier);                                                                        // 100
  },                                                                                                              //
  orionAccountsUpdateProfile: function (modifier, userId) {                                                       // 102
    if (!Roles.userHasPermission(this.userId, 'accounts.update.profile', userId)) {                               // 103
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 104
    }                                                                                                             //
    Meteor.users.update(userId, modifier);                                                                        // 106
  },                                                                                                              //
  removeUser: function (userId) {                                                                                 // 108
    check(userId, String);                                                                                        // 109
    if (!Roles.userHasPermission(this.userId, 'accounts.remove', userId)) {                                       // 110
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 111
    }                                                                                                             //
    Meteor.users.remove({ _id: userId });                                                                         // 113
  },                                                                                                              //
  adminSendEnrollmentEmail: function (userId) {                                                                   // 115
    check(userId, String);                                                                                        // 116
    Roles.checkPermission(this.userId, 'accounts.index');                                                         // 117
    return Accounts.sendEnrollmentEmail(userId);                                                                  // 118
  }                                                                                                               //
});                                                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/server.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({                                                                                                  // 1
  accountsCreateUser: function (options) {                                                                        // 2
    check(options, {                                                                                              // 3
      email: String,                                                                                              // 4
      password: Match.Optional(String),                                                                           // 5
      name: Match.Optional(String),                                                                               // 6
      roles: [String]                                                                                             // 7
    });                                                                                                           //
                                                                                                                  //
    if (!Roles.userHasPermission(Meteor.userId(), 'accounts.create')) {                                           // 10
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 11
    }                                                                                                             //
                                                                                                                  //
    var newUser = { email: options.email };                                                                       // 14
    if (options.password) {                                                                                       // 15
      newUser.password = options.password;                                                                        // 16
    }                                                                                                             //
    if (!!options.name) {                                                                                         // 18
      newUser.profile = { name: options.name };                                                                   // 19
    }                                                                                                             //
                                                                                                                  //
    var userId = Accounts.createUser(newUser);                                                                    // 22
                                                                                                                  //
    Roles.setUserRoles(userId, options.roles);                                                                    // 24
                                                                                                                  //
    return userId;                                                                                                // 26
  }                                                                                                               //
});                                                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:accounts'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_accounts.js.map
