(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_filesystem/filesystem.js                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
orion.filesystem = {};                                               // 1
                                                                     //
/**                                                                  //
 * Files stored in the database                                      //
 */                                                                  //
orion.filesystem.collection = new Mongo.Collection('orionFiles');    // 6
                                                                     //
/**                                                                  //
 * Files collection schema                                           //
 */                                                                  //
orion.filesystem.collection.attachSchema(new SimpleSchema({          // 11
  url: {                                                             // 12
    type: String                                                     // 13
  },                                                                 //
  name: {                                                            // 15
    type: String                                                     // 16
  },                                                                 //
  uploader: {                                                        // 18
    type: String                                                     // 19
  },                                                                 //
  meta: {                                                            // 21
    type: Object,                                                    // 22
    optional: true,                                                  // 23
    blackbox: true                                                   // 24
  }                                                                  //
}));                                                                 //
                                                                     //
/**                                                                  //
 * TODO: fix permissions here                                        //
 */                                                                  //
orion.filesystem.collection.allow({                                  // 31
  insert: function (userId, doc) {                                   // 32
    return true;                                                     // 33
  },                                                                 //
  update: function (userId, doc, fields, modifier) {                 // 35
    return true;                                                     // 36
  },                                                                 //
  remove: function (userId, doc) {                                   // 38
    return true;                                                     // 39
  }                                                                  //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orionjs_filesystem/filesystem_server.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Meteor.methods({                                                     // 1
  getFileDataToEarse: function (fileId) {                            // 2
    check(fileId, String);                                           // 3
    return orion.filesystem.collection.findOne(fileId);              // 4
  }                                                                  //
});                                                                  //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:filesystem'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_filesystem.js.map
