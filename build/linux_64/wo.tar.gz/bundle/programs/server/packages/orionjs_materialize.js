(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var Tabular = Package['nicolaslopezj:tabular-materialize'].Tabular;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var ECMAScript = Package.ecmascript.ECMAScript;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var orion;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/orionjs_materialize/init.js                                                    //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
Options.init('homePath');                                                                  // 1
Options.init('siteName');                                                                  // 2
Options.init('materialize.headerColor');                                                   // 3
                                                                                           //
ReactiveTemplates.request('tabs', 'orionMaterializeTabs');                                 // 5
                                                                                           //
ReactiveTemplates.request('materializeHeader', 'orionMaterializeHeaderContainer');         // 7
ReactiveTemplates.request('materializeContent', 'orionMaterializeContentContainer');       // 8
ReactiveTemplates.request('materializeButtons', 'orionMaterializeButtonsContainer');       // 9
                                                                                           //
ReactiveTemplates.set('layout', 'orionMaterializeLayout');                                 // 11
ReactiveTemplates.set('outAdminLayout', 'orionMaterializeOutAdminLayout');                 // 12
                                                                                           //
ReactiveTemplates.set('login', 'orionMaterializeLogin');                                   // 14
ReactiveTemplates.set('registerWithInvitation', 'orionMaterializeRegisterWithInvitation');
                                                                                           //
ReactiveTemplates.set('myAccount.index', 'orionMaterializeAccountIndex');                  // 17
ReactiveTemplates.set('myAccount.password', 'orionMaterializeAccountPassword');            // 18
ReactiveTemplates.set('myAccount.profile', 'orionMaterializeAccountProfile');              // 19
                                                                                           //
ReactiveTemplates.set('accounts.index', 'orionMaterializeAccountsIndex');                  // 21
ReactiveTemplates.set('accounts.update', 'orionMaterializeAccountsUpdate');                // 22
ReactiveTemplates.set('accounts.create', 'orionMaterializeAccountsCreate');                // 23
                                                                                           //
ReactiveTemplates.set('configUpdate', 'orionMaterializeConfigUpdate');                     // 25
ReactiveTemplates.set('dictionaryUpdate', 'orionMaterializeDictionaryUpdate');             // 26
                                                                                           //
// Set the default entity templates                                                        //
Options.set('collectionsDefaultIndexTemplate', 'orionMaterializeCollectionsIndex');        // 29
Options.set('collectionsDefaultCreateTemplate', 'orionMaterializeCollectionsCreate');      // 30
Options.set('collectionsDefaultUpdateTemplate', 'orionMaterializeCollectionsUpdate');      // 31
Options.set('collectionsDefaultDeleteTemplate', 'orionMaterializeCollectionsDelete');      // 32
                                                                                           //
// Orion attributes replace                                                                //
ReactiveTemplates.set('attribute.file', 'orionMaterializeFileAttribute');                  // 35
ReactiveTemplates.set('attribute.hasOne', 'orionMaterializeHasOneAttribute');              // 36
ReactiveTemplates.set('attribute.hasMany', 'orionMaterializeHasManyAttribute');            // 37
ReactiveTemplates.set('attribute.user', 'orionMaterializeHasOneAttribute');                // 38
ReactiveTemplates.set('attribute.users', 'orionMaterializeHasManyAttribute');              // 39
                                                                                           //
// Pages                                                                                   //
ReactiveTemplates.set('pages.index', 'orionMaterializePagesIndex');                        // 42
ReactiveTemplates.set('pages.create', 'orionMaterializePagesCreate');                      // 43
ReactiveTemplates.set('pages.update', 'orionMaterializePagesUpdate');                      // 44
ReactiveTemplates.set('pages.delete', 'orionMaterializePagesDelete');                      // 45
                                                                                           //
if (Meteor.isClient) {                                                                     // 47
  AutoForm.setDefaultTemplate('materialize');                                              // 48
                                                                                           //
  Meteor.startup(function () {                                                             // 50
    Session.set('orion_autoformLoading', false);                                           // 51
  });                                                                                      //
                                                                                           //
  AutoForm.addHooks(null, {                                                                // 54
    beginSubmit: function () {                                                             // 55
      Session.set('orion_autoformLoading', true);                                          // 56
    },                                                                                     //
    endSubmit: function () {                                                               // 58
      Session.set('orion_autoformLoading', false);                                         // 59
    }                                                                                      //
  });                                                                                      //
                                                                                           //
  Template.registerHelper('orion_autoformLoading', function () {                           // 63
    return Session.get('orion_autoformLoading') ? 'disabled' : '';                         // 64
  });                                                                                      //
                                                                                           //
  Template.registerHelper('materializeHeader', function () {                               // 68
    return ReactiveTemplates.get('materializeHeader');                                     // 69
  });                                                                                      //
                                                                                           //
  Template.registerHelper('materializeContent', function () {                              // 72
    return ReactiveTemplates.get('materializeContent');                                    // 73
  });                                                                                      //
                                                                                           //
  Template.registerHelper('materializeButtons', function () {                              // 76
    return ReactiveTemplates.get('materializeButtons');                                    // 77
  });                                                                                      //
}                                                                                          //
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/orionjs_materialize/tabular.js                                                 //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
orion.collections.onCreated(function () {                                                  // 1
  var self = this;                                                                         // 2
  // if the collection doesn't has the tabular option, nothing to do here!                 //
  if (!_.has(this, 'tabular')) return;                                                     // 4
                                                                                           //
  var tabularOptions = _.extend({                                                          // 6
    name: 'tabular_' + self.name,                                                          // 7
    collection: self,                                                                      // 8
    columns: [{ data: "_id", title: "ID" }],                                               // 9
    stateSave: true,                                                                       // 12
    selector: function (userId) {                                                          // 13
      var selectors = Roles.helper(userId, 'collections.' + self.name + '.indexFilter');   // 14
      return { $or: selectors };                                                           // 15
    },                                                                                     //
    language: {                                                                            // 17
      search: i18n('tabular.search'),                                                      // 18
      info: i18n('tabular.info'),                                                          // 19
      infoEmpty: i18n('tabular.infoEmpty'),                                                // 20
      lengthMenu: i18n('tabular.lengthMenu'),                                              // 21
      emptyTable: i18n('tabular.emptyTable'),                                              // 22
      paginate: {                                                                          // 23
        first: i18n('tabular.paginate.first'),                                             // 24
        previous: i18n('tabular.paginate.previous'),                                       // 25
        next: i18n('tabular.paginate.next'),                                               // 26
        last: i18n('tabular.paginate.last')                                                // 27
      }                                                                                    //
    }                                                                                      //
  }, this.tabular);                                                                        //
                                                                                           //
  Tracker.autorun(function () {                                                            // 32
    tabularOptions.columns.map(function (column) {                                         // 33
      if (_.isFunction(column.title)) {                                                    // 34
        column.langTitle = column.title;                                                   // 35
      }                                                                                    //
      if (_.isFunction(column.langTitle)) {                                                // 37
        column.title = column.langTitle();                                                 // 38
      }                                                                                    //
      return column;                                                                       // 40
    });                                                                                    //
    self.tabularTable = new Tabular.Table(tabularOptions);                                 // 42
  });                                                                                      //
});                                                                                        //
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:materialize'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_materialize.js.map
