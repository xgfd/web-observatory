(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var moment = Package['momentjs:moment'].moment;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gildaspk:autoform-materialize'] = {};

})();

//# sourceMappingURL=gildaspk_autoform-materialize.js.map
